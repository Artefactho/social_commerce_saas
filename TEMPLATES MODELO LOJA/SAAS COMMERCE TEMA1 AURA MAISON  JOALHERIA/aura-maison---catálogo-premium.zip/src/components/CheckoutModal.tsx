import React, { useState } from 'react';
import { 
  X, 
  CheckCircle2, 
  CreditCard, 
  QrCode, 
  FileText, 
  Truck, 
  ShieldCheck, 
  Lock, 
  Copy, 
  Check, 
  PhoneCall, 
  ArrowRight, 
  ArrowLeft 
} from 'lucide-react';
import { CartItem, OrderDetails } from '../types';
import { formatCurrency, STORE_INFO } from '../data/products';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  couponCode?: string;
  discountAmount: number;
  onSuccessOrder: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  couponCode,
  discountAmount,
  onSuccessOrder
}) => {
  const [step, setStep] = useState<'form' | 'payment' | 'confirmation'>('form');
  const [paymentMethod, setPaymentMethod] = useState<'pix' | 'credit_card' | 'boleto'>('pix');
  const [installments, setInstallments] = useState(1);
  const [copiedPix, setCopiedPix] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form State
  const [form, setForm] = useState({
    name: 'Helena Montenegro',
    email: 'helena.montenegro@email.com',
    phone: '(11) 99876-5432',
    cpf: '123.456.789-00',
    cep: '01452-000',
    street: 'Rua Oscar Freire',
    number: '1020',
    complement: 'Apto 142',
    neighborhood: 'Cerqueira César',
    city: 'São Paulo',
    state: 'SP',
    cardNumber: '•••• •••• •••• 4892',
    cardName: 'HELENA MONTENEGRO',
    cardExpiry: '12/29',
    cardCvv: '883'
  });

  const [completedOrder, setCompletedOrder] = useState<OrderDetails | null>(null);

  if (!isOpen) return null;

  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const isFreeShipping = subtotal >= STORE_INFO.freeShippingThreshold || subtotal === 0;
  const shippingCost = isFreeShipping ? 0 : STORE_INFO.defaultShippingCost;
  
  // Extra 5% off on Pix
  const pixDiscount = paymentMethod === 'pix' ? (subtotal - discountAmount) * 0.05 : 0;
  const total = Math.max(0, subtotal - discountAmount - pixDiscount + shippingCost);

  const mockPixCode = `00020126580014br.gov.bcb.pix0136auramaison-pix-${Math.floor(100000 + Math.random() * 900000)}520400005303986540${total.toFixed(2)}5802BR5915AURA MAISON SA6009SAO PAULO62070503***6304`;

  const handleCopyPix = () => {
    navigator.clipboard.writeText(mockPixCode);
    setCopiedPix(true);
    setTimeout(() => setCopiedPix(false), 2000);
  };

  const handleProcessOrder = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      const newOrderNumber = `AM-${Math.floor(100000 + Math.random() * 900000)}`;
      const order: OrderDetails = {
        customerName: form.name,
        email: form.email,
        phone: form.phone,
        cpf: form.cpf,
        cep: form.cep,
        street: form.street,
        number: form.number,
        complement: form.complement,
        neighborhood: form.neighborhood,
        city: form.city,
        state: form.state,
        paymentMethod,
        installments: paymentMethod === 'credit_card' ? installments : 1,
        couponCode,
        discountAmount: discountAmount + pixDiscount,
        subtotal,
        shipping: shippingCost,
        total,
        items,
        orderNumber: newOrderNumber,
        orderDate: new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })
      };
      setCompletedOrder(order);
      setStep('confirmation');
      onSuccessOrder();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      
      <div 
        id="checkout-modal-card"
        className="relative bg-[#FAF8F5] w-full max-w-2xl rounded-3xl shadow-2xl border border-[#D5C7B0] overflow-hidden my-auto animate-in zoom-in-95 duration-200"
      >
        {/* Header */}
        <div className="p-5 border-b border-[#E8DFCFA] bg-[#F2EDE2] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-stone-900 text-amber-200 flex items-center justify-center font-serif text-sm font-bold">
              AM
            </div>
            <div>
              <h3 className="font-serif-luxury text-xl font-bold text-stone-900">
                {step === 'confirmation' ? 'Pedido Confirmado com Sucesso!' : 'Finalização de Compra Segura'}
              </h3>
              <p className="text-[11px] text-stone-500 flex items-center gap-1">
                <Lock className="w-3 h-3 text-emerald-600" />
                <span>Ambiente Seguro com Criptografia SSL 256-bit</span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full text-stone-500 hover:text-stone-900 hover:bg-stone-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 max-h-[75vh] overflow-y-auto space-y-6">
          
          {/* STEP 1: Identification & Address */}
          {step === 'form' && (
            <div className="space-y-5 animate-in fade-in duration-200">
              
              {/* Step indicator */}
              <div className="flex items-center justify-between text-xs font-semibold text-stone-500 pb-2 border-b border-[#E8DFCFA]">
                <span className="text-amber-800 font-bold">1. Dados Pessoais & Endereço</span>
                <span>Etapa 1 de 2</span>
              </div>

              {/* Personal Data */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-stone-800 mb-3">
                  Seus Dados para Contato
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] text-stone-600 font-medium mb-1">Nome Completo</label>
                    <input
                      type="text"
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      className="w-full text-xs px-3 py-2.5 rounded-xl bg-white border border-[#D5C7B0] focus:outline-hidden focus:border-stone-800"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-stone-600 font-medium mb-1">E-mail para Confirmação</label>
                    <input
                      type="email"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      className="w-full text-xs px-3 py-2.5 rounded-xl bg-white border border-[#D5C7B0] focus:outline-hidden focus:border-stone-800"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-stone-600 font-medium mb-1">WhatsApp / Telefone</label>
                    <input
                      type="text"
                      value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      className="w-full text-xs px-3 py-2.5 rounded-xl bg-white border border-[#D5C7B0] focus:outline-hidden focus:border-stone-800"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-stone-600 font-medium mb-1">CPF (Nota Fiscal)</label>
                    <input
                      type="text"
                      value={form.cpf}
                      onChange={(e) => setForm({ ...form, cpf: e.target.value })}
                      className="w-full text-xs px-3 py-2.5 rounded-xl bg-white border border-[#D5C7B0] focus:outline-hidden focus:border-stone-800"
                    />
                  </div>
                </div>
              </div>

              {/* Delivery Address */}
              <div className="pt-3 border-t border-[#E8DFCFA]">
                <h4 className="text-xs font-bold uppercase tracking-wider text-stone-800 mb-3 flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 text-amber-800" />
                  <span>Endereço de Entrega</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] text-stone-600 font-medium mb-1">CEP</label>
                    <input
                      type="text"
                      value={form.cep}
                      onChange={(e) => setForm({ ...form, cep: e.target.value })}
                      className="w-full text-xs px-3 py-2.5 rounded-xl bg-white border border-[#D5C7B0] focus:outline-hidden focus:border-stone-800"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-[11px] text-stone-600 font-medium mb-1">Logradouro / Rua</label>
                    <input
                      type="text"
                      value={form.street}
                      onChange={(e) => setForm({ ...form, street: e.target.value })}
                      className="w-full text-xs px-3 py-2.5 rounded-xl bg-white border border-[#D5C7B0] focus:outline-hidden focus:border-stone-800"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-stone-600 font-medium mb-1">Número</label>
                    <input
                      type="text"
                      value={form.number}
                      onChange={(e) => setForm({ ...form, number: e.target.value })}
                      className="w-full text-xs px-3 py-2.5 rounded-xl bg-white border border-[#D5C7B0] focus:outline-hidden focus:border-stone-800"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-stone-600 font-medium mb-1">Complemento</label>
                    <input
                      type="text"
                      value={form.complement}
                      onChange={(e) => setForm({ ...form, complement: e.target.value })}
                      placeholder="Ex: Apto 101"
                      className="w-full text-xs px-3 py-2.5 rounded-xl bg-white border border-[#D5C7B0] focus:outline-hidden focus:border-stone-800"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-stone-600 font-medium mb-1">Bairro</label>
                    <input
                      type="text"
                      value={form.neighborhood}
                      onChange={(e) => setForm({ ...form, neighborhood: e.target.value })}
                      className="w-full text-xs px-3 py-2.5 rounded-xl bg-white border border-[#D5C7B0] focus:outline-hidden focus:border-stone-800"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-[11px] text-stone-600 font-medium mb-1">Cidade</label>
                    <input
                      type="text"
                      value={form.city}
                      onChange={(e) => setForm({ ...form, city: e.target.value })}
                      className="w-full text-xs px-3 py-2.5 rounded-xl bg-white border border-[#D5C7B0] focus:outline-hidden focus:border-stone-800"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-stone-600 font-medium mb-1">Estado (UF)</label>
                    <input
                      type="text"
                      value={form.state}
                      onChange={(e) => setForm({ ...form, state: e.target.value })}
                      className="w-full text-xs px-3 py-2.5 rounded-xl bg-white border border-[#D5C7B0] focus:outline-hidden focus:border-stone-800 uppercase"
                    />
                  </div>
                </div>
              </div>

              {/* Next Step Button */}
              <button
                onClick={() => setStep('payment')}
                className="w-full py-3.5 px-6 rounded-2xl bg-stone-900 hover:bg-stone-800 text-amber-200 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition-all"
              >
                <span>Avançar para Pagamento</span>
                <ArrowRight className="w-4 h-4" />
              </button>

            </div>
          )}

          {/* STEP 2: Payment Options */}
          {step === 'payment' && (
            <div className="space-y-5 animate-in fade-in duration-200">
              
              {/* Step indicator */}
              <div className="flex items-center justify-between text-xs font-semibold text-stone-500 pb-2 border-b border-[#E8DFCFA]">
                <button
                  onClick={() => setStep('form')}
                  className="text-stone-600 hover:text-stone-900 flex items-center gap-1"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Voltar aos dados</span>
                </button>
                <span className="text-amber-800 font-bold">2. Forma de Pagamento</span>
              </div>

              {/* Payment Method Selector Tabs */}
              <div className="grid grid-cols-3 gap-2 sm:gap-3">
                
                {/* PIX Option */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod('pix')}
                  className={`p-3 rounded-2xl border flex flex-col items-center justify-center text-center transition-all ${
                    paymentMethod === 'pix'
                      ? 'border-emerald-700 bg-emerald-50/70 text-emerald-950 ring-2 ring-emerald-700/20'
                      : 'border-stone-300 bg-white text-stone-700 hover:border-stone-400'
                  }`}
                >
                  <QrCode className="w-5 h-5 text-emerald-700 mb-1" />
                  <span className="text-xs font-bold">PIX Instantâneo</span>
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-200/60 px-2 py-0.5 rounded-full mt-1">
                    5% OFF EXTRA
                  </span>
                </button>

                {/* Credit Card Option */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod('credit_card')}
                  className={`p-3 rounded-2xl border flex flex-col items-center justify-center text-center transition-all ${
                    paymentMethod === 'credit_card'
                      ? 'border-amber-800 bg-amber-50/70 text-stone-950 ring-2 ring-amber-800/20'
                      : 'border-stone-300 bg-white text-stone-700 hover:border-stone-400'
                  }`}
                >
                  <CreditCard className="w-5 h-5 text-amber-800 mb-1" />
                  <span className="text-xs font-bold">Cartão de Crédito</span>
                  <span className="text-[10px] text-stone-500 mt-1">
                    Até 10x sem juros
                  </span>
                </button>

                {/* Boleto Option */}
                <button
                  type="button"
                  onClick={() => setPaymentMethod('boleto')}
                  className={`p-3 rounded-2xl border flex flex-col items-center justify-center text-center transition-all ${
                    paymentMethod === 'boleto'
                      ? 'border-stone-800 bg-stone-100 text-stone-950 ring-2 ring-stone-800/20'
                      : 'border-stone-300 bg-white text-stone-700 hover:border-stone-400'
                  }`}
                >
                  <FileText className="w-5 h-5 text-stone-700 mb-1" />
                  <span className="text-xs font-bold">Boleto Bancário</span>
                  <span className="text-[10px] text-stone-500 mt-1">
                    Compensação 1-2 dias
                  </span>
                </button>

              </div>

              {/* Payment Details Container */}
              {paymentMethod === 'pix' && (
                <div className="p-4 rounded-2xl bg-emerald-50/50 border border-emerald-200/80 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-emerald-950">
                        Pagamento via Chave / QR Code PIX
                      </h4>
                      <p className="text-[11px] text-emerald-800">
                        Aprovação imediata e envio prioritário no mesmo dia
                      </p>
                    </div>
                    <span className="text-xs font-black text-emerald-950">
                      Total com 5% OFF: {formatCurrency(total)}
                    </span>
                  </div>

                  <div className="flex flex-col sm:flex-row items-center gap-4 bg-white p-3 rounded-xl border border-emerald-100">
                    <div className="w-24 h-24 bg-stone-900 text-white rounded-xl p-2 flex flex-col items-center justify-center shrink-0">
                      <QrCode className="w-16 h-16 text-amber-200" />
                      <span className="text-[8px] tracking-widest font-mono uppercase text-stone-300">PIX QR CODE</span>
                    </div>

                    <div className="flex-1 w-full space-y-1.5">
                      <label className="text-[10px] font-bold uppercase text-stone-500">
                        Código Copia e Cola:
                      </label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          readOnly
                          value={mockPixCode}
                          className="w-full text-[11px] font-mono p-2 rounded-lg bg-stone-50 border border-stone-200 truncate"
                        />
                        <button
                          type="button"
                          onClick={handleCopyPix}
                          className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold flex items-center gap-1 shrink-0"
                        >
                          {copiedPix ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedPix ? 'Copiado!' : 'Copiar'}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {paymentMethod === 'credit_card' && (
                <div className="p-4 rounded-2xl bg-white border border-[#D5C7B0] space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="sm:col-span-2">
                      <label className="block text-[11px] text-stone-600 font-medium mb-1">Número do Cartão</label>
                      <input
                        type="text"
                        value={form.cardNumber}
                        onChange={(e) => setForm({ ...form, cardNumber: e.target.value })}
                        className="w-full text-xs px-3 py-2.5 rounded-xl bg-white border border-[#D5C7B0] focus:outline-hidden"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-stone-600 font-medium mb-1">Nome Gravado no Cartão</label>
                      <input
                        type="text"
                        value={form.cardName}
                        onChange={(e) => setForm({ ...form, cardName: e.target.value })}
                        className="w-full text-xs px-3 py-2.5 rounded-xl bg-white border border-[#D5C7B0] focus:outline-hidden uppercase"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[11px] text-stone-600 font-medium mb-1">Validade</label>
                        <input
                          type="text"
                          value={form.cardExpiry}
                          onChange={(e) => setForm({ ...form, cardExpiry: e.target.value })}
                          className="w-full text-xs px-3 py-2.5 rounded-xl bg-white border border-[#D5C7B0] focus:outline-hidden"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-stone-600 font-medium mb-1">CVV</label>
                        <input
                          type="password"
                          maxLength={4}
                          value={form.cardCvv}
                          onChange={(e) => setForm({ ...form, cardCvv: e.target.value })}
                          className="w-full text-xs px-3 py-2.5 rounded-xl bg-white border border-[#D5C7B0] focus:outline-hidden"
                        />
                      </div>
                    </div>
                    
                    <div className="sm:col-span-2">
                      <label className="block text-[11px] text-stone-600 font-medium mb-1">Opções de Parcelamento</label>
                      <select
                        value={installments}
                        onChange={(e) => setInstallments(Number(e.target.value))}
                        className="w-full text-xs px-3 py-2.5 rounded-xl bg-white border border-[#D5C7B0] focus:outline-hidden font-medium text-stone-800"
                      >
                        {[1, 2, 3, 4, 5, 6, 8, 10].map((num) => (
                          <option key={num} value={num}>
                            {num}x de {formatCurrency(total / num)} sem juros
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {paymentMethod === 'boleto' && (
                <div className="p-4 rounded-2xl bg-stone-100 border border-stone-200 text-xs text-stone-700 space-y-2">
                  <p className="font-semibold text-stone-900">
                    O boleto bancário será gerado e enviado para seu e-mail após a confirmação.
                  </p>
                  <p className="text-stone-500 text-[11px]">
                    Vencimento em 2 dias úteis. A liberação do pedido ocorre mediante confirmação bancária.
                  </p>
                </div>
              )}

              {/* Order Total Summary Bar */}
              <div className="p-3.5 rounded-2xl bg-[#F2EDE2] border border-[#E0D5C3] flex items-center justify-between text-xs">
                <div>
                  <span className="text-stone-500 block text-[11px]">Total do Pedido</span>
                  <span className="font-serif-luxury text-xl font-bold text-stone-950">{formatCurrency(total)}</span>
                </div>
                <div className="text-right text-[11px] text-stone-600">
                  <span>{items.length} itens inclusos &bull; {isFreeShipping ? 'Frete Grátis' : 'Frete R$ 28'}</span>
                </div>
              </div>

              {/* Confirm Order Button */}
              <button
                id="btn-confirm-order-action"
                onClick={handleProcessOrder}
                disabled={isSubmitting}
                className="w-full py-3.5 px-6 rounded-2xl bg-stone-900 hover:bg-stone-800 text-amber-200 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl transition-all"
              >
                {isSubmitting ? (
                  <div className="flex items-center gap-2">
                    <span className="w-4 h-4 rounded-full border-2 border-amber-300 border-t-transparent animate-spin"></span>
                    <span>Processando seu Pedido...</span>
                  </div>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>Confirmar e Finalizar Pedido</span>
                  </>
                )}
              </button>

            </div>
          )}

          {/* STEP 3: Order Confirmation Success */}
          {step === 'confirmation' && completedOrder && (
            <div className="space-y-6 text-center py-2 animate-in zoom-in-95 duration-300">
              
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto ring-8 ring-emerald-50">
                <CheckCircle2 className="w-9 h-9" />
              </div>

              <div>
                <span className="text-xs uppercase font-bold tracking-widest text-amber-800">
                  Pedido Realizado com Sucesso
                </span>
                <h3 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-stone-900 mt-1">
                  Obrigado, {completedOrder.customerName}!
                </h3>
                <p className="text-xs text-stone-500 mt-1">
                  Enviamos o comprovante completo para <strong>{completedOrder.email}</strong>
                </p>
              </div>

              {/* Order Receipt Box */}
              <div className="bg-[#F4EFE6] rounded-2xl p-4 border border-[#E2D8C7] text-left text-xs space-y-2">
                <div className="flex justify-between border-b border-[#E0D4C0] pb-2 font-bold text-stone-800">
                  <span>Número do Pedido:</span>
                  <span className="font-mono text-amber-900">{completedOrder.orderNumber}</span>
                </div>
                <div className="flex justify-between text-stone-600">
                  <span>Data da Compra:</span>
                  <span>{completedOrder.orderDate}</span>
                </div>
                <div className="flex justify-between text-stone-600">
                  <span>Entrega para:</span>
                  <span>{completedOrder.street}, {completedOrder.number} — {completedOrder.city}/{completedOrder.state}</span>
                </div>
                <div className="flex justify-between text-stone-600">
                  <span>Forma de Pagamento:</span>
                  <span className="uppercase font-semibold text-stone-800">{completedOrder.paymentMethod}</span>
                </div>
                <div className="flex justify-between border-t border-[#E0D4C0] pt-2 font-bold text-stone-950 text-sm">
                  <span>Valor Total:</span>
                  <span>{formatCurrency(completedOrder.total)}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 pt-2">
                <a
                  href={`https://wa.me/5511987654321?text=${encodeURIComponent(`Olá! Gostaria de acompanhar meu pedido ${completedOrder.orderNumber} na Aura Maison.`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3 px-4 rounded-2xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold flex items-center justify-center gap-2 transition-colors"
                >
                  <PhoneCall className="w-4 h-4" />
                  <span>Acompanhar Pedido no WhatsApp</span>
                </a>

                <button
                  onClick={onClose}
                  className="w-full py-3 px-4 rounded-2xl bg-stone-900 hover:bg-stone-800 text-amber-200 text-xs font-bold uppercase tracking-wider transition-colors"
                >
                  Continuar Explorando o Catálogo
                </button>
              </div>

            </div>
          )}

        </div>

      </div>

    </div>
  );
};

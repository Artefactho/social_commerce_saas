import React from 'react';
import { Truck, CreditCard, RefreshCw, PhoneCall, ShieldCheck, Sparkles } from 'lucide-react';

export const FeaturesBar: React.FC = () => {
  const features = [
    {
      icon: <Truck className="w-6 h-6 text-amber-700" />,
      title: "Frete Grátis Brasil",
      description: "Em pedidos a partir de R$ 350 com rastreio prioritário."
    },
    {
      icon: <CreditCard className="w-6 h-6 text-amber-700" />,
      title: "Até 10x Sem Juros",
      description: "Aceitamos todos os cartões e 5% de desconto no Pix."
    },
    {
      icon: <RefreshCw className="w-6 h-6 text-amber-700" />,
      title: "Primeira Troca Grátis",
      description: "30 dias para devolução ou troca sem burocracia."
    },
    {
      icon: <PhoneCall className="w-6 h-6 text-amber-700" />,
      title: "Concierge VIP",
      description: "Atendimento personalizado e humanizado via WhatsApp."
    }
  ];

  return (
    <section id="features-trust-bar" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {features.map((f, i) => (
          <div
            key={i}
            className="bg-[#FAF6F0] p-4 sm:p-5 rounded-2xl sm:rounded-3xl border border-[#E8DFCFA] shadow-2xs hover:shadow-md hover:border-[#D8CCB8] transition-all duration-300 flex items-start gap-3.5"
          >
            <div className="w-11 h-11 rounded-2xl bg-[#F0E6D5] flex items-center justify-center shrink-0 border border-[#DFD3C0]">
              {f.icon}
            </div>
            <div>
              <h4 className="font-serif-luxury text-base font-bold text-stone-900 leading-snug">
                {f.title}
              </h4>
              <p className="text-xs text-stone-600 mt-0.5 leading-relaxed">
                {f.description}
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

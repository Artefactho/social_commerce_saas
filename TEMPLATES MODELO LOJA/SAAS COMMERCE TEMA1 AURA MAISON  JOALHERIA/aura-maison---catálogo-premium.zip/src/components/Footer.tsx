import React, { useState } from 'react';
import { 
  Instagram, 
  Send, 
  ShieldCheck, 
  Lock, 
  PhoneCall, 
  Mail, 
  MapPin, 
  Check, 
  Sparkles, 
  QrCode, 
  CreditCard 
} from 'lucide-react';
import { STORE_INFO, CATEGORIES } from '../data/products';

interface FooterProps {
  onSelectCategory: (categoryId: string) => void;
  onOpenAbout: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectCategory, onOpenAbout }) => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail.trim()) {
      setSubscribed(true);
      setTimeout(() => {
        setSubscribed(false);
        setNewsletterEmail('');
      }, 4000);
    }
  };

  return (
    <footer id="main-store-footer" className="bg-[#1C1916] text-[#E8DFD3] pt-14 pb-8 border-t border-[#2F2923] mt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Newsletter Card with Soft Rounded Edges */}
        <div className="bg-linear-to-r from-[#2B241E] to-[#221D18] rounded-3xl p-6 sm:p-10 border border-[#3E342B] mb-12 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="max-w-md text-center md:text-left">
            <div className="inline-flex items-center gap-2 text-amber-300 text-xs font-bold uppercase tracking-widest mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Clube Privé Aura</span>
            </div>
            <h3 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-white leading-tight">
              Receba Convites e Lançamentos
            </h3>
            <p className="text-xs text-stone-300 mt-1 font-light">
              Assine nossa correspondência semanal e ganhe 10% OFF no seu primeiro pedido com curadoria exclusiva.
            </p>
          </div>

          <div className="w-full md:w-auto flex-1 max-w-md">
            {subscribed ? (
              <div className="bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 px-4 py-3 rounded-2xl text-xs flex items-center justify-center gap-2 text-center">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>Bem-vindo à Maison! Use o cupom <strong>PRIMEIRACOMPRA</strong></span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex gap-2">
                <input
                  type="email"
                  required
                  placeholder="Seu melhor e-mail..."
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  className="flex-1 bg-[#191613] border border-[#443A30] text-stone-100 placeholder-stone-400 text-xs px-4 py-3 rounded-2xl focus:outline-hidden focus:border-amber-400"
                />
                <button
                  type="submit"
                  className="bg-linear-to-r from-amber-400 to-amber-300 hover:from-amber-300 hover:to-amber-200 text-stone-950 text-xs font-bold uppercase tracking-wider px-5 py-3 rounded-2xl flex items-center gap-2 shadow-md transition-all shrink-0"
                >
                  <span>Assinar</span>
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            )}
          </div>
        </div>

        {/* 4 Footer Columns */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 pb-12 border-b border-[#312B24]">
          
          {/* Column 1: Brand & Round Logo */}
          <div className="space-y-4 text-center sm:text-left">
            <div className="flex items-center justify-center sm:justify-start gap-3">
              <div className="w-12 h-12 rounded-full bg-linear-to-b from-[#2E2822] to-[#1E1A16] border border-amber-400/40 p-0.5 shadow-md flex items-center justify-center">
                <div className="w-full h-full rounded-full border border-dashed border-amber-300/40 flex items-center justify-center bg-[#181512]">
                  <span className="font-serif-luxury text-lg font-bold text-amber-200">AM</span>
                </div>
              </div>
              <div>
                <span className="font-serif-luxury text-lg font-bold tracking-[0.2em] text-white block">
                  AURA MAISON
                </span>
                <span className="text-[9px] uppercase tracking-[0.25em] text-amber-300 block font-medium -mt-1">
                  Haute Curadoria
                </span>
              </div>
            </div>

            <p className="text-xs text-stone-300 leading-relaxed font-light">
              Catálogo virtual de alta joalheria, bolsas em couro nobre e artigos de luxo com atendimento exclusivo para todo o Brasil.
            </p>

            <div className="flex items-center justify-center sm:justify-start gap-3 pt-2">
              <a
                href={STORE_INFO.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-full bg-[#2A231C] hover:bg-emerald-900 text-stone-300 hover:text-emerald-300 border border-[#3E342B] flex items-center justify-center transition-colors"
                title="WhatsApp"
              >
                <PhoneCall className="w-4 h-4" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-full bg-[#2A231C] hover:bg-rose-900 text-stone-300 hover:text-rose-300 border border-[#3E342B] flex items-center justify-center transition-colors"
                title="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Column 2: 1. Coleções */}
          <div>
            <h4 className="font-serif-luxury text-base font-bold text-white mb-4 uppercase tracking-wider text-xs">
              1. Coleções & Catálogo
            </h4>
            <ul className="space-y-2.5 text-xs text-stone-300">
              {CATEGORIES.map((cat) => (
                <li key={cat.id}>
                  <button
                    onClick={() => onSelectCategory(cat.id)}
                    className="hover:text-amber-300 transition-colors"
                  >
                    {cat.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: 2. Destaques & Informações */}
          <div>
            <h4 className="font-serif-luxury text-base font-bold text-white mb-4 uppercase tracking-wider text-xs">
              2. Destaques & Suporte
            </h4>
            <ul className="space-y-2.5 text-xs text-stone-300">
              <li>
                <button onClick={onOpenAbout} className="hover:text-amber-300 transition-colors">
                  Sobre a Aura Maison
                </button>
              </li>
              <li>
                <button onClick={onOpenAbout} className="hover:text-amber-300 transition-colors">
                  Certificado de Autenticidade
                </button>
              </li>
              <li>
                <button onClick={onOpenAbout} className="hover:text-amber-300 transition-colors">
                  Guia de Cuidados com Joias
                </button>
              </li>
              <li>
                <a href={STORE_INFO.whatsappUrl} target="_blank" rel="noopener noreferrer" className="hover:text-amber-300 transition-colors">
                  Política de Trocas & Devoluções
                </a>
              </li>
              <li>
                <a href={STORE_INFO.whatsappUrl} target="_blank" rel="noopener noreferrer" className="hover:text-amber-300 transition-colors">
                  Rastreamento de Encomendas
                </a>
              </li>
            </ul>
          </div>

          {/* Column 4: 3. Atendimento & Contato */}
          <div>
            <h4 className="font-serif-luxury text-base font-bold text-white mb-4 uppercase tracking-wider text-xs">
              3. Concierge & Atelier
            </h4>
            <div className="space-y-3 text-xs text-stone-300">
              <p className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-amber-300 shrink-0 mt-0.5" />
                <span>{STORE_INFO.address}</span>
              </p>
              <p className="flex items-center gap-2">
                <PhoneCall className="w-4 h-4 text-amber-300 shrink-0" />
                <span>WhatsApp: {STORE_INFO.phone}</span>
              </p>
              <p className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-amber-300 shrink-0" />
                <span>{STORE_INFO.email}</span>
              </p>
              <div className="p-3 rounded-xl bg-[#251F1A] border border-[#3A3026] text-[11px] text-stone-400 mt-2">
                Horário de Atendimento VIP: <br />
                Segunda a Sábado, das 09h às 20h.
              </div>
            </div>
          </div>

        </div>

        {/* Payment Methods & Security Seals Bar */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-stone-400">
          
          {/* Payment Badges */}
          <div className="flex items-center flex-wrap justify-center gap-2">
            <span className="text-[11px] font-semibold text-stone-300 mr-1">Pagamento Seguro:</span>
            <span className="px-2.5 py-1 rounded-lg bg-[#251F1A] border border-[#3D3328] text-[10px] font-bold text-amber-200 flex items-center gap-1">
              <QrCode className="w-3 h-3 text-emerald-400" /> PIX (5% OFF)
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-[#251F1A] border border-[#3D3328] text-[10px] font-bold text-stone-300 flex items-center gap-1">
              <CreditCard className="w-3 h-3 text-amber-400" /> Cartão até 10x
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-[#251F1A] border border-[#3D3328] text-[10px] text-stone-300">
              Mastercard
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-[#251F1A] border border-[#3D3328] text-[10px] text-stone-300">
              Visa
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-[#251F1A] border border-[#3D3328] text-[10px] text-stone-300">
              Elo
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-[#251F1A] border border-[#3D3328] text-[10px] text-stone-300">
              Boleto
            </span>
          </div>

          {/* Security Badges */}
          <div className="flex items-center gap-4 text-[11px] text-stone-400">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Site Seguro SSL</span>
            </span>
            <span className="flex items-center gap-1">
              <Lock className="w-4 h-4 text-amber-300" />
              <span>Privacidade Garantida</span>
            </span>
          </div>

        </div>

        {/* Copyright */}
        <div className="text-center text-[10px] text-stone-500 pt-6 mt-6 border-t border-[#29231D]">
          <p>© {new Date().getFullYear()} AURA MAISON DO BRASIL LTDA. &bull; CNPJ 42.189.921/0001-84 &bull; Todos os direitos reservados.</p>
          <p className="mt-0.5">Preços e condições de pagamento válidos exclusivamente para o catálogo virtual.</p>
        </div>

      </div>
    </footer>
  );
};

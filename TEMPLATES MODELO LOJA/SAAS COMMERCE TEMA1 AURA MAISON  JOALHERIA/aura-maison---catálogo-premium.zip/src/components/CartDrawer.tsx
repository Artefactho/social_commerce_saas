import React, { useState } from 'react';
import { 
  X, 
  Trash2, 
  ShoppingBag, 
  ArrowRight, 
  Tag, 
  Truck, 
  ShieldCheck, 
  PhoneCall, 
  Sparkles, 
  Check 
} from 'lucide-react';
import { CartItem } from '../types';
import { formatCurrency, STORE_INFO, PROMO_COUPONS } from '../data/products';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
  onOpenCheckout: (appliedCoupon?: string, discount?: number) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onOpenCheckout
}) => {
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);
  const [couponError, setCouponError] = useState<string | null>(null);

  if (!isOpen) return null;

  const subtotal = items.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );

  const discountPercent = appliedCoupon ? PROMO_COUPONS[appliedCoupon] || 0 : 0;
  const discountAmount = subtotal * discountPercent;
  
  const isFreeShipping = subtotal >= STORE_INFO.freeShippingThreshold || subtotal === 0;
  const shippingCost = isFreeShipping ? 0 : STORE_INFO.defaultShippingCost;
  const total = Math.max(0, subtotal - discountAmount + shippingCost);

  const remainingForFreeShipping = Math.max(
    0,
    STORE_INFO.freeShippingThreshold - subtotal
  );
  const freeShippingProgress = Math.min(
    100,
    (subtotal / STORE_INFO.freeShippingThreshold) * 100
  );

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = couponCode.trim().toUpperCase();
    if (PROMO_COUPONS[clean]) {
      setAppliedCoupon(clean);
      setCouponError(null);
    } else {
      setCouponError('Cupom inválido. Tente PRIMEIRACOMPRA ou AURA5');
    }
  };

  const handleRemoveCoupon = () => {
    setAppliedCoupon(null);
    setCouponCode('');
    setCouponError(null);
  };

  // WhatsApp Order message builder
  const buildWhatsAppOrderLink = () => {
    let text = `*NOVO PEDIDO - AURA MAISON*\n`;
    text += `Olá, gostaria de fechar meu pedido feito pelo catálogo virtual:\n\n`;
    items.forEach((item, index) => {
      text += `${index + 1}. *${item.product.name}*\n`;
      text += `   Qtd: ${item.quantity}x | Valor: ${formatCurrency(item.product.price * item.quantity)}\n`;
      if (item.selectedColor) text += `   Cor: ${item.selectedColor}\n`;
      if (item.selectedSize) text += `   Tamanho: ${item.selectedSize}\n`;
      text += `   Ref: ${item.product.sku}\n\n`;
    });
    text += `*Subtotal:* ${formatCurrency(subtotal)}\n`;
    if (appliedCoupon) {
      text += `*Cupom aplicado:* ${appliedCoupon} (-${formatCurrency(discountAmount)})\n`;
    }
    text += `*Frete:* ${isFreeShipping ? 'GRÁTIS' : formatCurrency(shippingCost)}\n`;
    text += `*VALOR TOTAL:* ${formatCurrency(total)}\n\n`;
    text += `Poderiam me enviar os dados para pagamento e confirmação de entrega?`;
    return `https://wa.me/5511987654321?text=${encodeURIComponent(text)}`;
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-stone-950/60 backdrop-blur-xs flex justify-end animate-in fade-in duration-200">
      
      {/* Click outside backdrop */}
      <div className="flex-1" onClick={onClose} />

      {/* Cart Container with Smooth Rounded Left Borders */}
      <div 
        id="cart-drawer"
        className="w-full max-w-md sm:max-w-lg bg-[#FAF8F5] h-full shadow-2xl flex flex-col justify-between border-l border-[#E2D7C5] animate-in slide-in-from-right duration-300 relative z-10"
      >
        
        {/* Cart Header */}
        <div className="p-4 sm:p-5 border-b border-[#EAE2D3] bg-[#F4EDE1]/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-stone-900 text-amber-200 flex items-center justify-center">
              <ShoppingBag className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-serif-luxury text-xl font-bold text-stone-900">
                Sua Sacola de Compras
              </h2>
              <p className="text-[11px] text-stone-500">
                {items.length} {items.length === 1 ? 'item selecionado' : 'itens selecionados'}
              </p>
            </div>
          </div>

          <button
            id="btn-close-cart"
            onClick={onClose}
            className="p-2 rounded-full text-stone-500 hover:text-stone-900 hover:bg-stone-200/60 transition-colors"
            aria-label="Fechar carrinho"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Shipping Progress Bar */}
        {items.length > 0 && (
          <div className="bg-[#ECE4D6] px-5 py-2.5 border-b border-[#E0D4C0]">
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="flex items-center gap-1.5 font-medium text-stone-800">
                <Truck className="w-3.5 h-3.5 text-amber-800" />
                {isFreeShipping ? (
                  <strong className="text-emerald-800">Parabéns! Você ganhou Frete Grátis!</strong>
                ) : (
                  <span>
                    Faltam <strong>{formatCurrency(remainingForFreeShipping)}</strong> para <strong>Frete Grátis</strong>
                  </span>
                )}
              </span>
              <span className="text-[10px] font-bold text-stone-500">
                {Math.round(freeShippingProgress)}%
              </span>
            </div>
            <div className="w-full bg-[#DFD5C4] h-2 rounded-full overflow-hidden">
              <div
                className="bg-linear-to-r from-amber-600 to-emerald-600 h-full rounded-full transition-all duration-500"
                style={{ width: `${freeShippingProgress}%` }}
              />
            </div>
          </div>
        )}

        {/* Items List Section */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
              <div className="w-20 h-20 rounded-full bg-[#EFE9DD] flex items-center justify-center text-stone-400">
                <ShoppingBag className="w-10 h-10 stroke-1" />
              </div>
              <div>
                <h3 className="font-serif-luxury text-xl font-bold text-stone-800 mb-1">
                  Sua sacola está vazia
                </h3>
                <p className="text-xs text-stone-500 max-w-xs leading-relaxed">
                  Adicione joias, bolsas e fragrâncias exclusivas para iniciar sua experiência.
                </p>
              </div>
              <button
                onClick={onClose}
                className="bg-stone-900 hover:bg-stone-800 text-amber-200 text-xs font-bold uppercase tracking-wider px-6 py-3 rounded-full shadow-md transition-all"
              >
                Explorar Catálogo
              </button>
            </div>
          ) : (
            items.map((item) => (
              <div
                key={item.id}
                className="flex gap-3.5 bg-[#FAF7F2] p-3 rounded-2xl border border-[#E8DFCFA] shadow-2xs hover:border-[#DACDB7] transition-colors"
              >
                {/* Product Thumbnail */}
                <div className="w-20 h-20 rounded-xl overflow-hidden bg-stone-200 shrink-0 border border-[#DFD3BE]">
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name}
                    className="w-full h-full object-cover object-center"
                  />
                </div>

                {/* Details & Controls */}
                <div className="flex-1 flex flex-col justify-between min-w-0">
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="font-serif-luxury font-bold text-stone-900 text-sm truncate">
                        {item.product.name}
                      </h4>
                      <button
                        onClick={() => onRemoveItem(item.id)}
                        className="text-stone-400 hover:text-rose-600 p-1 transition-colors"
                        title="Remover produto"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Variations */}
                    <div className="text-[11px] text-stone-500 flex items-center gap-2 mt-0.5">
                      {item.selectedColor && (
                        <span>Cor: <strong>{item.selectedColor}</strong></span>
                      )}
                      {item.selectedSize && (
                        <span>Tam: <strong>{item.selectedSize}</strong></span>
                      )}
                    </div>
                  </div>

                  {/* Quantity Stepper & Subtotal */}
                  <div className="flex items-center justify-between mt-2">
                    <div className="flex items-center border border-[#D5C9B5] rounded-xl bg-white p-0.5">
                      <button
                        onClick={() => onUpdateQuantity(item.id, -1)}
                        className="w-6 h-6 rounded-lg flex items-center justify-center text-stone-700 hover:bg-stone-100 text-xs font-bold"
                      >
                        -
                      </button>
                      <span className="w-6 text-center text-xs font-bold text-stone-900">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => onUpdateQuantity(item.id, 1)}
                        className="w-6 h-6 rounded-lg flex items-center justify-center text-stone-700 hover:bg-stone-100 text-xs font-bold"
                      >
                        +
                      </button>
                    </div>

                    <div className="text-right">
                      <div className="text-sm font-bold text-stone-900">
                        {formatCurrency(item.product.price * item.quantity)}
                      </div>
                      <div className="text-[10px] text-stone-400">
                        {item.quantity}x {formatCurrency(item.product.price)}
                      </div>
                    </div>
                  </div>

                </div>
              </div>
            ))
          )}
        </div>

        {/* Cart Footer: Summary, Coupon & Actions */}
        {items.length > 0 && (
          <div className="p-4 sm:p-5 border-t border-[#EAE2D3] bg-[#F7F2E8]/90 space-y-3">
            
            {/* Coupon Box */}
            <div>
              {appliedCoupon ? (
                <div className="flex items-center justify-between bg-emerald-50 border border-emerald-300/80 px-3 py-2 rounded-xl text-xs text-emerald-900">
                  <div className="flex items-center gap-2">
                    <Tag className="w-3.5 h-3.5 text-emerald-600" />
                    <span>
                      Cupom <strong>{appliedCoupon}</strong> (-{Math.round(discountPercent * 100)}%)
                    </span>
                  </div>
                  <button
                    onClick={handleRemoveCoupon}
                    className="text-stone-500 hover:text-stone-900 text-xs underline ml-2"
                  >
                    Remover
                  </button>
                </div>
              ) : (
                <form onSubmit={handleApplyCoupon} className="flex gap-2">
                  <div className="relative flex-1">
                    <input
                      type="text"
                      placeholder="Cupom (ex: PRIMEIRACOMPRA)"
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                      className="w-full text-xs px-3 py-2 rounded-xl bg-white border border-[#D5C9B5] focus:outline-hidden focus:border-stone-800 uppercase"
                    />
                    <Tag className="w-3 h-3 text-stone-400 absolute right-3 top-2.5 pointer-events-none" />
                  </div>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-stone-800 hover:bg-stone-900 text-amber-200 rounded-xl text-xs font-bold tracking-wider uppercase"
                  >
                    Aplicar
                  </button>
                </form>
              )}
              {couponError && (
                <p className="text-[10px] text-rose-600 mt-1">{couponError}</p>
              )}
            </div>

            {/* Price Calculations Breakdown */}
            <div className="space-y-1.5 text-xs text-stone-600 pt-1">
              <div className="flex justify-between">
                <span>Subtotal dos produtos</span>
                <span className="font-semibold text-stone-800">{formatCurrency(subtotal)}</span>
              </div>

              {discountAmount > 0 && (
                <div className="flex justify-between text-emerald-700 font-medium">
                  <span>Desconto de cupom</span>
                  <span>-{formatCurrency(discountAmount)}</span>
                </div>
              )}

              <div className="flex justify-between">
                <span>Frete Express</span>
                <span className={isFreeShipping ? 'text-emerald-700 font-bold' : 'font-semibold text-stone-800'}>
                  {isFreeShipping ? 'GRÁTIS' : formatCurrency(shippingCost)}
                </span>
              </div>

              <div className="flex justify-between items-baseline pt-2 border-t border-[#E2D8C7] text-stone-900">
                <span className="font-serif-luxury text-base font-bold">Total a Pagar</span>
                <div className="text-right">
                  <span className="font-black text-xl text-stone-950">
                    {formatCurrency(total)}
                  </span>
                  <p className="text-[10px] text-emerald-800 font-medium">
                    ou em até 10x de {formatCurrency(total / 10)} sem juros
                  </p>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2 pt-1">
              {/* Checkout Simulator */}
              <button
                id="btn-cart-checkout"
                onClick={() => onOpenCheckout(appliedCoupon || undefined, discountAmount)}
                className="w-full py-3.5 px-6 rounded-2xl bg-stone-900 hover:bg-stone-800 text-amber-200 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition-all transform active:scale-98"
              >
                <span>Finalizar Pedido na Loja</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              {/* WhatsApp Checkout direct */}
              <a
                href={buildWhatsAppOrderLink()}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-4 rounded-2xl border border-emerald-600/50 bg-emerald-50 hover:bg-emerald-100/90 text-emerald-900 text-xs font-bold flex items-center justify-center gap-2 transition-colors"
              >
                <PhoneCall className="w-3.5 h-3.5 text-emerald-600" />
                <span>Comprar Direto pelo WhatsApp</span>
              </a>
            </div>

            {/* Security trust badge */}
            <div className="flex items-center justify-center gap-1.5 text-[10px] text-stone-500 text-center pt-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Ambiente 100% Criptografado &bull; Compra Segura</span>
            </div>

          </div>
        )}

      </div>

    </div>
  );
};

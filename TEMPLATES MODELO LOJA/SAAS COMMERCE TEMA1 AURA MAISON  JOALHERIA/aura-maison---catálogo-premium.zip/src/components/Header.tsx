import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Heart, 
  Search, 
  Menu, 
  X, 
  ChevronDown, 
  PhoneCall, 
  Sparkles, 
  Star, 
  Compass, 
  Gem, 
  ShieldCheck, 
  Layers
} from 'lucide-react';
import { CATEGORIES, STORE_INFO } from '../data/products';

interface HeaderProps {
  cartCount: number;
  wishlistCount: number;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onSelectCategory: (categoryId: string) => void;
  selectedCategory: string;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onOpenAbout: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  cartCount,
  wishlistCount,
  onOpenCart,
  onOpenWishlist,
  onSelectCategory,
  selectedCategory,
  searchQuery,
  onSearchChange,
  onOpenAbout
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isSearchExpanded, setIsSearchExpanded] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  const handleCategoryClick = (categoryId: string) => {
    onSelectCategory(categoryId);
    setMobileMenuOpen(false);
    setActiveDropdown(null);
    const catalogEl = document.getElementById('catalogo-section');
    if (catalogEl) {
      catalogEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header 
      id="main-store-header" 
      className="sticky top-0 z-40 bg-[#FAF8F5]/95 backdrop-blur-md border-b border-[#E8E1D5] transition-shadow duration-300 shadow-xs"
    >
      {/* Top Header Main Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex items-center justify-between gap-4">
          
          {/* LEFT SECTION: Search & Menu 1 */}
          <div className="flex items-center gap-3 lg:gap-6 flex-1 justify-start">
            {/* Mobile Menu Toggle Button */}
            <button
              id="btn-mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-full text-stone-700 hover:bg-[#F0EBE1] transition-colors"
              aria-label="Abrir menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            {/* Quick Search Bar */}
            <div className="relative hidden md:block w-52 lg:w-64">
              <input
                id="header-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Buscar no catálogo..."
                className="w-full bg-[#F3EDE2] text-stone-800 placeholder-stone-400 text-xs rounded-full pl-9 pr-4 py-2 border border-[#E4DBCB] focus:outline-hidden focus:border-stone-500 focus:bg-white transition-all shadow-2xs"
              />
              <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5 pointer-events-none" />
              {searchQuery && (
                <button 
                  onClick={() => onSearchChange('')}
                  className="absolute right-3 top-2.5 text-stone-400 hover:text-stone-700 text-xs"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Nav Menu 1: Coleções & Categorias (Desktop Left) */}
            <div className="hidden lg:flex items-center">
              <div 
                className="relative"
                onMouseEnter={() => setActiveDropdown('menu1')}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <button
                  id="nav-menu-1-btn"
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold uppercase tracking-wider text-stone-700 hover:text-stone-950 hover:bg-[#F0EAE0] transition-all"
                >
                  <Layers className="w-3.5 h-3.5 text-amber-700" />
                  <span>1. Coleções</span>
                  <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${activeDropdown === 'menu1' ? 'rotate-180' : ''}`} />
                </button>

                {/* Dropdown Menu 1 */}
                {activeDropdown === 'menu1' && (
                  <div className="absolute left-0 mt-1 w-64 bg-white/98 backdrop-blur-md rounded-2xl shadow-xl border border-[#E6DEC6] p-2 z-50 animate-in fade-in slide-in-from-top-1 duration-150">
                    <div className="text-[10px] uppercase font-bold text-stone-400 tracking-wider px-3 py-1.5 border-b border-stone-100">
                      Categorias em Destaque
                    </div>
                    {CATEGORIES.map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => handleCategoryClick(cat.id)}
                        className={`w-full text-left flex items-center justify-between px-3 py-2 rounded-xl text-xs transition-colors ${
                          selectedCategory === cat.id 
                            ? 'bg-amber-50 text-amber-950 font-semibold' 
                            : 'text-stone-700 hover:bg-stone-50 hover:text-stone-950'
                        }`}
                      >
                        <span>{cat.name}</span>
                        {cat.id !== 'todos' && (
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-600/40"></span>
                        )}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* CENTER SECTION: ROUND CENTERED LOGO */}
          <div className="flex flex-col items-center justify-center shrink-0">
            <a 
              href="#" 
              onClick={(e) => {
                e.preventDefault();
                onSelectCategory('todos');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="group flex flex-col items-center focus:outline-hidden"
              id="store-logo-link"
            >
              {/* Round Luxury Logo Badge */}
              <div className="relative w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-gradient-to-b from-[#FAF6F0] via-[#F2ECE0] to-[#E5DBCB] p-0.5 shadow-md group-hover:shadow-lg transition-all duration-300 transform group-hover:scale-105 border border-[#D5C7B2]">
                <div className="w-full h-full rounded-full border border-dashed border-[#B8A388] flex flex-col items-center justify-center bg-[#FAF8F5] relative overflow-hidden">
                  {/* Subtle inner decorative glow */}
                  <div className="absolute inset-0 bg-radial from-amber-100/40 to-transparent pointer-events-none"></div>
                  
                  {/* Monogram */}
                  <span className="font-serif-luxury text-xl sm:text-2xl font-bold tracking-tight text-stone-900 leading-none select-none">
                    AM
                  </span>
                  {/* Fine star detail */}
                  <span className="text-[7px] text-amber-700 font-semibold tracking-widest uppercase leading-none mt-0.5">
                    ✦ PARIS ✦
                  </span>
                </div>
              </div>

              {/* Brand Typography Title Below Circle */}
              <div className="text-center mt-1">
                <span className="block font-serif-luxury text-base sm:text-lg font-bold tracking-[0.25em] text-stone-900 uppercase">
                  AURA MAISON
                </span>
                <span className="block text-[8px] sm:text-[9px] uppercase tracking-[0.3em] text-stone-500 font-medium -mt-1">
                  Haute Curadoria
                </span>
              </div>
            </a>
          </div>

          {/* RIGHT SECTION: Menu 2, Menu 3 & Action Utilities */}
          <div className="flex items-center gap-2 sm:gap-4 flex-1 justify-end">
            
            {/* Nav Menu 2: Destaques & Tendências (Desktop Right) */}
            <div className="hidden lg:flex items-center">
              <div 
                className="relative"
                onMouseEnter={() => setActiveDropdown('menu2')}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <button
                  id="nav-menu-2-btn"
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold uppercase tracking-wider text-stone-700 hover:text-stone-950 hover:bg-[#F0EAE0] transition-all"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-700" />
                  <span>2. Destaques</span>
                  <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${activeDropdown === 'menu2' ? 'rotate-180' : ''}`} />
                </button>

                {/* Dropdown Menu 2 */}
                {activeDropdown === 'menu2' && (
                  <div className="absolute right-0 mt-1 w-60 bg-white/98 backdrop-blur-md rounded-2xl shadow-xl border border-[#E6DEC6] p-2 z-50 animate-in fade-in slide-in-from-top-1 duration-150">
                    <div className="text-[10px] uppercase font-bold text-stone-400 tracking-wider px-3 py-1.5 border-b border-stone-100">
                      Curadoria Especial
                    </div>
                    <button
                      onClick={() => handleCategoryClick('todos')}
                      className="w-full text-left flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-stone-700 hover:bg-stone-50 hover:text-stone-950 transition-colors"
                    >
                      <Star className="w-3.5 h-3.5 text-amber-500" />
                      <span>Mais Vendidos & Best Sellers</span>
                    </button>
                    <button
                      onClick={() => handleCategoryClick('joias')}
                      className="w-full text-left flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-stone-700 hover:bg-stone-50 hover:text-stone-950 transition-colors"
                    >
                      <Gem className="w-3.5 h-3.5 text-amber-600" />
                      <span>Novas Joias & Ouro 18k</span>
                    </button>
                    <button
                      onClick={() => handleCategoryClick('bolsas')}
                      className="w-full text-left flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-stone-700 hover:bg-stone-50 hover:text-stone-950 transition-colors"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                      <span>Edição Limitada Riviera</span>
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Nav Menu 3: Experiência & Atendimento (Desktop Right) */}
            <div className="hidden xl:flex items-center">
              <div 
                className="relative"
                onMouseEnter={() => setActiveDropdown('menu3')}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <button
                  id="nav-menu-3-btn"
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold uppercase tracking-wider text-stone-700 hover:text-stone-950 hover:bg-[#F0EAE0] transition-all"
                >
                  <Compass className="w-3.5 h-3.5 text-amber-700" />
                  <span>3. Experiência</span>
                  <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${activeDropdown === 'menu3' ? 'rotate-180' : ''}`} />
                </button>

                {/* Dropdown Menu 3 */}
                {activeDropdown === 'menu3' && (
                  <div className="absolute right-0 mt-1 w-64 bg-white/98 backdrop-blur-md rounded-2xl shadow-xl border border-[#E6DEC6] p-2 z-50 animate-in fade-in slide-in-from-top-1 duration-150">
                    <div className="text-[10px] uppercase font-bold text-stone-400 tracking-wider px-3 py-1.5 border-b border-stone-100">
                      Maison Concierge
                    </div>
                    <button
                      onClick={onOpenAbout}
                      className="w-full text-left flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-stone-700 hover:bg-stone-50 hover:text-stone-950 transition-colors"
                    >
                      <ShieldCheck className="w-3.5 h-3.5 text-stone-500" />
                      <span>Nossa História & Garantias</span>
                    </button>
                    <a
                      href={STORE_INFO.whatsappUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full text-left flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-emerald-800 hover:bg-emerald-50 transition-colors"
                    >
                      <PhoneCall className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Atendimento VIP no WhatsApp</span>
                    </a>
                  </div>
                )}
              </div>
            </div>

            {/* Mobile Search Button */}
            <button
              id="btn-mobile-search-toggle"
              onClick={() => setIsSearchExpanded(!isSearchExpanded)}
              className="md:hidden p-2 rounded-full text-stone-700 hover:bg-[#F0EBE1] transition-colors"
              aria-label="Buscar"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Wishlist Button with Badge */}
            <button
              id="btn-open-wishlist"
              onClick={onOpenWishlist}
              className="relative p-2.5 rounded-full bg-[#F3EDE2] text-stone-700 hover:text-rose-700 hover:bg-[#EBE2D3] border border-[#E3D9C7] transition-all"
              title="Lista de Desejos"
              aria-label="Lista de Desejos"
            >
              <Heart className="w-4 h-4" />
              {wishlistCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-rose-600 text-white font-bold text-[10px] w-4 h-4 rounded-full flex items-center justify-center ring-2 ring-[#FAF8F5]">
                  {wishlistCount}
                </span>
              )}
            </button>

            {/* Shopping Cart Button with Badge */}
            <button
              id="btn-open-cart"
              onClick={onOpenCart}
              className="relative flex items-center gap-2 bg-[#1F1C19] hover:bg-[#2C2723] text-[#FAF8F5] px-3.5 py-2 rounded-full transition-all shadow-xs group"
              title="Sacola de Compras"
              aria-label="Sacola de Compras"
            >
              <div className="relative">
                <ShoppingBag className="w-4 h-4 text-amber-300 group-hover:scale-110 transition-transform" />
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-amber-400 text-stone-950 font-extrabold text-[10px] w-4 h-4 rounded-full flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </div>
              <span className="hidden sm:inline text-xs font-medium tracking-wide">
                Sacola {cartCount > 0 ? `(${cartCount})` : ''}
              </span>
            </button>
          </div>

        </div>

        {/* Mobile Search Expandable Bar */}
        {isSearchExpanded && (
          <div className="mt-2.5 pt-2 pb-1 border-t border-[#E8E1D5] md:hidden animate-in fade-in duration-200">
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Pesquisar por joia, bolsa, perfume..."
                autoFocus
                className="w-full bg-[#F3EDE2] text-stone-800 placeholder-stone-500 text-xs rounded-full pl-9 pr-8 py-2.5 border border-[#DFD5C2] focus:outline-hidden focus:border-stone-500"
              />
              <Search className="w-4 h-4 text-stone-400 absolute left-3 top-3 pointer-events-none" />
              {searchQuery && (
                <button 
                  onClick={() => onSearchChange('')}
                  className="absolute right-3 top-2.5 text-stone-500 text-sm"
                >
                  ✕
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Secondary Quick Navigation Bar with 3 Highlight Categories */}
      <nav className="bg-[#F2ECE1]/80 border-t border-[#E8E1D5] px-4 py-1.5 overflow-x-auto no-scrollbar">
        <div className="max-w-7xl mx-auto flex items-center justify-center sm:justify-center gap-2 sm:gap-6 text-xs whitespace-nowrap">
          <span className="text-[10px] uppercase tracking-widest text-stone-400 font-bold hidden sm:inline">
            Navegação Rápida:
          </span>
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => handleCategoryClick(cat.id)}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                selectedCategory === cat.id
                  ? 'bg-stone-900 text-amber-200 shadow-2xs'
                  : 'text-stone-700 hover:text-stone-950 hover:bg-stone-200/50'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </nav>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden bg-stone-900/60 backdrop-blur-xs flex">
          <div className="bg-[#FAF8F5] w-4/5 max-w-sm h-full p-6 flex flex-col justify-between shadow-2xl overflow-y-auto">
            <div>
              {/* Drawer Header */}
              <div className="flex items-center justify-between pb-4 border-b border-[#E8E1D5]">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-stone-900 text-amber-200 flex items-center justify-center font-serif text-sm font-bold">
                    AM
                  </div>
                  <span className="font-serif-luxury font-bold text-stone-900 tracking-wider">
                    AURA MAISON
                  </span>
                </div>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1 rounded-full text-stone-500 hover:bg-stone-100"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* 3 Main Menus for Mobile */}
              <div className="mt-6 space-y-6">
                {/* Menu 1 Section */}
                <div>
                  <h4 className="text-[11px] font-bold uppercase tracking-wider text-amber-800 mb-2.5 flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5" />
                    1. Catálogo & Coleções
                  </h4>
                  <div className="space-y-1 pl-2">
                    {CATEGORIES.map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => handleCategoryClick(cat.id)}
                        className={`w-full text-left py-1.5 px-3 rounded-lg text-xs flex items-center justify-between ${
                          selectedCategory === cat.id
                            ? 'bg-amber-100/80 font-bold text-stone-900'
                            : 'text-stone-700 hover:bg-stone-100'
                        }`}
                      >
                        <span>{cat.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Menu 2 Section */}
                <div className="pt-2 border-t border-[#EAE3D6]">
                  <h4 className="text-[11px] font-bold uppercase tracking-wider text-amber-800 mb-2.5 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    2. Destaques & Tendências
                  </h4>
                  <div className="space-y-1 pl-2">
                    <button
                      onClick={() => handleCategoryClick('todos')}
                      className="w-full text-left py-1.5 px-3 rounded-lg text-xs text-stone-700 hover:bg-stone-100"
                    >
                      Best Sellers da Temporada
                    </button>
                    <button
                      onClick={() => handleCategoryClick('joias')}
                      className="w-full text-left py-1.5 px-3 rounded-lg text-xs text-stone-700 hover:bg-stone-100"
                    >
                      Lançamento Ouro & Diamantes
                    </button>
                    <button
                      onClick={() => handleCategoryClick('bolsas')}
                      className="w-full text-left py-1.5 px-3 rounded-lg text-xs text-stone-700 hover:bg-stone-100"
                    >
                      Couros Exclusivos Riviera
                    </button>
                  </div>
                </div>

                {/* Menu 3 Section */}
                <div className="pt-2 border-t border-[#EAE3D6]">
                  <h4 className="text-[11px] font-bold uppercase tracking-wider text-amber-800 mb-2.5 flex items-center gap-1.5">
                    <Compass className="w-3.5 h-3.5" />
                    3. Atendimento & Maison
                  </h4>
                  <div className="space-y-1 pl-2">
                    <button
                      onClick={() => {
                        setMobileMenuOpen(false);
                        onOpenAbout();
                      }}
                      className="w-full text-left py-1.5 px-3 rounded-lg text-xs text-stone-700 hover:bg-stone-100"
                    >
                      Sobre a Marca & Certificados
                    </button>
                    <a
                      href={STORE_INFO.whatsappUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full text-left py-1.5 px-3 rounded-lg text-xs text-emerald-800 font-medium flex items-center gap-2"
                    >
                      <PhoneCall className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Concierge WhatsApp VIP</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Mobile Footer Drawer */}
            <div className="pt-4 border-t border-[#E8E1D5] text-xs text-stone-500">
              <p className="text-[11px]">{STORE_INFO.address}</p>
              <p className="text-[11px] font-semibold text-stone-700 mt-1">Tel: {STORE_INFO.phone}</p>
            </div>
          </div>
          
          <div className="flex-1" onClick={() => setMobileMenuOpen(false)}></div>
        </div>
      )}
    </header>
  );
};

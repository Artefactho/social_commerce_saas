import React from 'react';
import { X, Heart, ShoppingBag, Trash2 } from 'lucide-react';
import { Product } from '../types';
import { formatCurrency } from '../data/products';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: Product[];
  onRemoveFromWishlist: (product: Product) => void;
  onMoveToCart: (product: Product) => void;
  onClearWishlist: () => void;
}

export const WishlistDrawer: React.FC<WishlistDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onRemoveFromWishlist,
  onMoveToCart,
  onClearWishlist
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-stone-950/60 backdrop-blur-xs flex justify-end animate-in fade-in duration-200">
      
      {/* Backdrop */}
      <div className="flex-1" onClick={onClose} />

      {/* Drawer */}
      <div 
        id="wishlist-drawer"
        className="w-full max-w-md bg-[#FAF8F5] h-full shadow-2xl flex flex-col justify-between border-l border-[#E2D7C5] animate-in slide-in-from-right duration-300 relative z-10"
      >
        
        {/* Header */}
        <div className="p-5 border-b border-[#EAE2D3] bg-[#F4EDE1] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center">
              <Heart className="w-4 h-4 fill-current" />
            </div>
            <div>
              <h2 className="font-serif-luxury text-xl font-bold text-stone-900">
                Lista de Desejos
              </h2>
              <p className="text-[11px] text-stone-500">
                {items.length} {items.length === 1 ? 'item salvo' : 'itens salvos'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full text-stone-500 hover:text-stone-900 hover:bg-stone-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* List of saved products */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3.5">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3">
              <div className="w-16 h-16 rounded-full bg-[#EFE9DD] flex items-center justify-center text-stone-400">
                <Heart className="w-8 h-8 stroke-1" />
              </div>
              <h3 className="font-serif-luxury text-lg font-bold text-stone-800">
                Nenhum item salvo
              </h3>
              <p className="text-xs text-stone-500 max-w-xs leading-relaxed">
                Clique no ícone de coração nos produtos para guardá-los e acompanhar depois.
              </p>
            </div>
          ) : (
            items.map((prod) => (
              <div
                key={prod.id}
                className="flex gap-3 bg-white p-3 rounded-2xl border border-[#E8DFCFA] shadow-2xs items-center justify-between"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-16 h-16 rounded-xl overflow-hidden bg-stone-100 shrink-0 border border-[#E0D4C0]">
                    <img
                      src={prod.images[0]}
                      alt={prod.name}
                      className="w-full h-full object-cover object-center"
                    />
                  </div>
                  <div className="min-w-0">
                    <h4 className="font-serif-luxury font-bold text-stone-900 text-xs truncate">
                      {prod.name}
                    </h4>
                    <p className="text-xs font-bold text-stone-900 mt-0.5">
                      {formatCurrency(prod.price)}
                    </p>
                    <span className="text-[10px] text-emerald-800 font-medium block">
                      Em 10x sem juros
                    </span>
                  </div>
                </div>

                <div className="flex flex-col gap-1.5 shrink-0 ml-2">
                  <button
                    onClick={() => onMoveToCart(prod)}
                    className="p-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-amber-200 text-xs flex items-center gap-1 shadow-2xs font-semibold"
                    title="Adicionar ao carrinho"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onRemoveFromWishlist(prod)}
                    className="p-2 rounded-xl bg-stone-100 hover:bg-rose-50 text-stone-400 hover:text-rose-600 transition-colors"
                    title="Remover"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {items.length > 0 && (
          <div className="p-4 border-t border-[#EAE2D3] bg-[#F7F2E8] flex items-center justify-between">
            <button
              onClick={onClearWishlist}
              className="text-xs text-stone-500 hover:text-stone-900 underline"
            >
              Limpar lista
            </button>
            <button
              onClick={onClose}
              className="bg-stone-900 text-amber-200 text-xs font-bold px-4 py-2 rounded-xl"
            >
              Continuar comprando
            </button>
          </div>
        )}

      </div>

    </div>
  );
};

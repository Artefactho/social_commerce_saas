import React, { useState, useEffect } from 'react';
import { Sparkles, Truck, ShieldCheck, ChevronRight, X } from 'lucide-react';

export const TopBanner: React.FC = () => {
  const [currentMessageIndex, setCurrentMessageIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  const announcements = [
    {
      icon: <Truck className="w-3.5 h-3.5 text-amber-300 inline mr-1.5" />,
      text: "FRETE GRÁTIS para todo o Brasil em pedidos acima de R$ 350",
      highlight: "APROVEITE"
    },
    {
      icon: <Sparkles className="w-3.5 h-3.5 text-amber-300 inline mr-1.5" />,
      text: "Ganhe 10% OFF na primeira compra com o cupom:",
      badge: "PRIMEIRACOMPRA"
    },
    {
      icon: <ShieldCheck className="w-3.5 h-3.5 text-amber-300 inline mr-1.5" />,
      text: "Parcelamento exclusivo em até 10x sem juros no cartão de crédito",
      highlight: "COMPRA SEGURA"
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentMessageIndex((prev) => (prev + 1) % announcements.length);
    }, 4500);
    return () => clearInterval(timer);
  }, [announcements.length]);

  if (!isVisible) return null;

  const current = announcements[currentMessageIndex];

  return (
    <div 
      id="top-announcement-banner" 
      className="bg-[#1A1816] text-[#F3EFEA] text-[11px] sm:text-xs tracking-wider border-b border-[#2C2723] py-2 px-3 sm:px-6 relative z-50 transition-all duration-300"
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Left subtle indicator */}
        <div className="hidden lg:flex items-center gap-2 text-[#A89F91] text-[11px]">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>Concierge Online &bull; Envio Imediato</span>
        </div>

        {/* Center rotating announcements */}
        <div className="flex-1 flex items-center justify-center text-center px-2 min-h-[22px]">
          <div className="flex items-center justify-center flex-wrap gap-1.5 font-medium transition-opacity duration-300">
            {current.icon}
            <span>{current.text}</span>
            {current.badge && (
              <span className="bg-amber-400/20 text-amber-200 border border-amber-400/30 px-2 py-0.5 rounded-full text-[10px] font-bold tracking-widest uppercase">
                {current.badge}
              </span>
            )}
            {current.highlight && (
              <span className="text-amber-300 font-semibold flex items-center text-[11px] underline underline-offset-2 ml-1 cursor-pointer hover:text-amber-200">
                {current.highlight}
                <ChevronRight className="w-3 h-3 ml-0.5" />
              </span>
            )}
          </div>
        </div>

        {/* Right utilities & close */}
        <div className="flex items-center gap-3 text-[#A89F91] text-[11px]">
          <span className="hidden sm:inline font-mono">BRL (R$)</span>
          <button
            id="btn-close-top-banner"
            onClick={() => setIsVisible(false)}
            className="p-0.5 rounded hover:text-white hover:bg-white/10 transition-colors"
            title="Fechar aviso"
            aria-label="Fechar aviso"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};

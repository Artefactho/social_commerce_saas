import React, { useState } from 'react';
import { 
  X, 
  ShoppingBag, 
  Heart, 
  Star, 
  Check, 
  Truck, 
  ShieldCheck, 
  PhoneCall, 
  Share2, 
  Layers, 
  Sparkles 
} from 'lucide-react';
import { Product } from '../types';
import { formatCurrency, STORE_INFO } from '../data/products';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, color?: string, size?: string, quantity?: number) => void;
  onToggleWishlist: (product: Product) => void;
  isWishlisted: boolean;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  onClose,
  onAddToCart,
  onToggleWishlist,
  isWishlisted
}) => {
  if (!product) return null;

  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [selectedColor, setSelectedColor] = useState<string | undefined>(
    product.colors?.[0]?.name
  );
  const [selectedSize, setSelectedSize] = useState<string | undefined>(
    product.sizes?.[0]
  );
  const [quantity, setQuantity] = useState(1);
  const [cepInput, setCepInput] = useState('');
  const [shippingResult, setShippingResult] = useState<string | null>(null);
  const [added, setAdded] = useState(false);

  const installmentCount = 10;
  const installmentValue = (product.price * quantity) / installmentCount;

  const handleAdd = () => {
    onAddToCart(product, selectedColor, selectedSize, quantity);
    setAdded(true);
    setTimeout(() => {
      setAdded(false);
      onClose();
    }, 1000);
  };

  const handleSimulateShipping = (e: React.FormEvent) => {
    e.preventDefault();
    if (cepInput.replace(/\D/g, '').length >= 8) {
      if (product.price * quantity >= STORE_INFO.freeShippingThreshold) {
        setShippingResult('Frete Grátis Express (3 a 5 dias úteis)');
      } else {
        setShippingResult(`Frete Seguro Express: ${formatCurrency(STORE_INFO.defaultShippingCost)} (3 a 5 dias úteis)`);
      }
    } else {
      setShippingResult('Por favor, informe um CEP válido com 8 dígitos.');
    }
  };

  const whatsappMessage = encodeURIComponent(
    `Olá! Tenho interesse no item do catálogo Aura Maison:\n*${product.name}*\nRef (SKU): ${product.sku}\nValor: ${formatCurrency(product.price)}\n${selectedColor ? `Cor: ${selectedColor}\n` : ''}${selectedSize ? `Tamanho: ${selectedSize}\n` : ''}Poderiam me fornecer mais detalhes?`
  );

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      
      {/* Modal Container with Rounded Smooth Design */}
      <div 
        id="product-detail-modal"
        className="relative bg-[#FAF8F5] w-full max-w-4xl rounded-3xl shadow-2xl border border-[#D8CCB8] overflow-hidden my-auto animate-in zoom-in-95 duration-200"
      >
        
        {/* Close Button */}
        <button
          id="btn-close-product-modal"
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2.5 rounded-full bg-white/90 hover:bg-white text-stone-700 hover:text-stone-950 shadow-md transition-colors"
          aria-label="Fechar"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 max-h-[85vh] overflow-y-auto">
          
          {/* Left Column: Image Gallery */}
          <div className="p-6 bg-[#F3EDE2] flex flex-col justify-between">
            {/* Main Active Image */}
            <div className="aspect-square w-full rounded-2xl overflow-hidden bg-[#ECE3D4] border border-[#E0D4C0] shadow-inner mb-4 relative">
              <img
                src={product.images[selectedImageIndex] || product.images[0]}
                alt={product.name}
                className="w-full h-full object-cover object-center transition-all duration-300"
              />
              {product.badge && (
                <div className="absolute top-3 left-3 bg-stone-900/90 text-amber-200 font-bold text-[10px] tracking-widest uppercase px-3 py-1 rounded-full shadow-xs">
                  {product.badge}
                </div>
              )}
            </div>

            {/* Thumbnail Navigation */}
            {product.images.length > 1 && (
              <div className="flex gap-2.5 overflow-x-auto pb-1">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setSelectedImageIndex(idx)}
                    className={`w-16 h-16 rounded-xl overflow-hidden border-2 transition-all shrink-0 ${
                      selectedImageIndex === idx
                        ? 'border-amber-700 ring-2 ring-amber-700/30'
                        : 'border-transparent opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="Miniatura" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right Column: Product Information & Purchase Controls */}
          <div className="p-6 sm:p-8 flex flex-col justify-between space-y-5">
            
            <div>
              {/* Category & SKU */}
              <div className="flex items-center justify-between text-xs text-stone-500 mb-1">
                <span className="uppercase tracking-widest font-bold text-amber-800">
                  {product.category}
                </span>
                <span className="font-mono text-[10px] text-stone-400">
                  SKU: {product.sku}
                </span>
              </div>

              {/* Title */}
              <h2 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-stone-900 leading-tight mb-2">
                {product.name}
              </h2>

              {/* Rating */}
              <div className="flex items-center gap-2 mb-4">
                <div className="flex text-amber-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>
                <span className="text-xs font-bold text-stone-800">{product.rating}</span>
                <span className="text-xs text-stone-500">({product.reviewsCount} avaliações de clientes)</span>
              </div>

              {/* Price */}
              <div className="p-3.5 rounded-2xl bg-[#F4EDE2] border border-[#E5DAC8] mb-4">
                <div className="flex items-baseline gap-2.5">
                  <span className="text-2xl sm:text-3xl font-black text-stone-900">
                    {formatCurrency(product.price * quantity)}
                  </span>
                  {product.originalPrice && (
                    <span className="text-sm text-stone-400 line-through">
                      {formatCurrency(product.originalPrice * quantity)}
                    </span>
                  )}
                </div>
                <p className="text-xs text-emerald-800 font-semibold mt-0.5">
                  Em até 10x de {formatCurrency(installmentValue)} sem juros no cartão
                </p>
                <p className="text-[11px] text-stone-600 mt-1">
                  Ou com <strong>5% de desconto no Pix</strong> por {formatCurrency(product.price * quantity * 0.95)}
                </p>
              </div>

              {/* Short Description */}
              <p className="text-xs sm:text-sm text-stone-700 leading-relaxed mb-4">
                {product.description}
              </p>

              {/* Color Options */}
              {product.colors && product.colors.length > 0 && (
                <div className="mb-4">
                  <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 mb-2">
                    Variação de Cor: <span className="font-semibold text-amber-900">{selectedColor}</span>
                  </label>
                  <div className="flex items-center gap-2">
                    {product.colors.map((c) => (
                      <button
                        key={c.name}
                        onClick={() => setSelectedColor(c.name)}
                        className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                          selectedColor === c.name
                            ? 'border-stone-900 bg-stone-900 text-white shadow-xs'
                            : 'border-stone-300 bg-white text-stone-700 hover:border-stone-400'
                        }`}
                      >
                        <span className="w-3 h-3 rounded-full border border-white/50" style={{ backgroundColor: c.hex }} />
                        <span>{c.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Size Options */}
              {product.sizes && product.sizes.length > 0 && (
                <div className="mb-4">
                  <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 mb-2">
                    Tamanho / Volume: <span className="font-semibold text-amber-900">{selectedSize}</span>
                  </label>
                  <div className="flex items-center gap-2 flex-wrap">
                    {product.sizes.map((s) => (
                      <button
                        key={s}
                        onClick={() => setSelectedSize(s)}
                        className={`px-4 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                          selectedSize === s
                            ? 'border-stone-900 bg-stone-900 text-white shadow-xs'
                            : 'border-stone-300 bg-white text-stone-700 hover:border-stone-400'
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Specifications / Materials info */}
              {(product.material || product.dimensions) && (
                <div className="text-[11px] text-stone-600 space-y-1 py-2 border-t border-b border-[#E8E1D5] mb-4">
                  {product.material && (
                    <div><strong>Material:</strong> {product.material}</div>
                  )}
                  {product.dimensions && (
                    <div><strong>Dimensões / Especificação:</strong> {product.dimensions}</div>
                  )}
                </div>
              )}
            </div>

            {/* Actions & Quantity */}
            <div className="space-y-3 pt-2">
              
              <div className="flex items-center gap-3">
                {/* Quantity Selector */}
                <div className="flex items-center border border-[#D5C9B5] rounded-2xl bg-white p-1">
                  <button
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    className="w-8 h-8 rounded-xl flex items-center justify-center text-stone-700 hover:bg-stone-100 font-bold"
                  >
                    -
                  </button>
                  <span className="w-8 text-center text-xs font-bold text-stone-900">{quantity}</span>
                  <button
                    onClick={() => setQuantity((q) => Math.min(product.stockCount || 10, q + 1))}
                    className="w-8 h-8 rounded-xl flex items-center justify-center text-stone-700 hover:bg-stone-100 font-bold"
                  >
                    +
                  </button>
                </div>

                {/* Primary Add to Cart Button */}
                <button
                  id="btn-modal-add-to-cart"
                  onClick={handleAdd}
                  disabled={!product.inStock}
                  className={`flex-1 py-3.5 px-6 rounded-2xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-md ${
                    added
                      ? 'bg-emerald-700 text-white'
                      : product.inStock
                      ? 'bg-stone-900 hover:bg-stone-800 text-amber-200'
                      : 'bg-stone-200 text-stone-400 cursor-not-allowed'
                  }`}
                >
                  {added ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-300" />
                      <span>Item Adicionado!</span>
                    </>
                  ) : (
                    <>
                      <ShoppingBag className="w-4 h-4" />
                      <span>Adicionar à Sacola</span>
                    </>
                  )}
                </button>

                {/* Wishlist Button */}
                <button
                  onClick={() => onToggleWishlist(product)}
                  className={`p-3.5 rounded-2xl border transition-all ${
                    isWishlisted
                      ? 'bg-rose-50 text-rose-600 border-rose-300'
                      : 'bg-white text-stone-700 border-[#D5C9B5] hover:text-rose-600'
                  }`}
                  title="Favoritar"
                >
                  <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
                </button>
              </div>

              {/* Direct WhatsApp Purchase Link */}
              <a
                href={`https://wa.me/5511987654321?text=${whatsappMessage}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-4 rounded-2xl border border-emerald-600/40 bg-emerald-50/70 hover:bg-emerald-100 text-emerald-900 text-xs font-bold flex items-center justify-center gap-2 transition-colors"
              >
                <PhoneCall className="w-3.5 h-3.5 text-emerald-600" />
                <span>Pedir ou Tirar Dúvidas no WhatsApp</span>
              </a>

              {/* Shipping Simulator */}
              <form onSubmit={handleSimulateShipping} className="pt-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Calcular CEP (ex: 01452-000)"
                    value={cepInput}
                    onChange={(e) => setCepInput(e.target.value)}
                    className="flex-1 text-xs px-3 py-2 rounded-xl bg-white border border-[#D5C9B5] focus:outline-hidden focus:border-stone-800"
                  />
                  <button
                    type="submit"
                    className="px-3 py-2 bg-[#E9E1D2] hover:bg-[#DCD2C0] text-stone-800 rounded-xl text-xs font-semibold"
                  >
                    Calcular
                  </button>
                </div>
                {shippingResult && (
                  <p className="text-[11px] text-stone-700 mt-1.5 flex items-center gap-1">
                    <Truck className="w-3.5 h-3.5 text-amber-700" />
                    <span>{shippingResult}</span>
                  </p>
                )}
              </form>

            </div>

          </div>

        </div>

      </div>

    </div>
  );
};

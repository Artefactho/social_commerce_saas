import React from 'react';
import { ArrowRight, Sparkles, ShieldCheck, Gem, Award } from 'lucide-react';

interface HeroCatalogBannerProps {
  onExploreClick: () => void;
  onSelectCategory: (categoryId: string) => void;
}

export const HeroCatalogBanner: React.FC<HeroCatalogBannerProps> = ({
  onExploreClick,
  onSelectCategory
}) => {
  return (
    <section id="hero-banner-section" className="relative px-4 sm:px-6 lg:px-8 pt-4 pb-8 max-w-7xl mx-auto">
      {/* Main Luxury Hero Card with Softened Rounded Edges */}
      <div className="relative overflow-hidden rounded-3xl bg-linear-to-r from-[#201C18] via-[#2D2620] to-[#1A1715] text-[#FAF8F5] shadow-xl border border-[#3E362F]/60">
        
        {/* Background Decorative Pattern & Gradient Orbs */}
        <div className="absolute -right-20 -top-20 w-96 h-96 rounded-full bg-amber-500/10 blur-3xl pointer-events-none"></div>
        <div className="absolute left-1/3 -bottom-20 w-80 h-80 rounded-full bg-amber-700/10 blur-3xl pointer-events-none"></div>

        <div className="grid grid-cols-1 lg:grid-cols-12 items-center min-h-[440px] relative z-10">
          
          {/* Text Content */}
          <div className="lg:col-span-7 p-6 sm:p-10 lg:p-14 flex flex-col justify-center">
            
            {/* Top Pill Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-400/15 border border-amber-400/30 text-amber-200 text-xs font-semibold tracking-wider uppercase w-fit mb-5 backdrop-blur-xs">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>Coleção Primavera &bull; Verão 2026</span>
            </div>

            {/* Main Headline */}
            <h1 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white leading-[1.15] mb-4">
              A Essência do Luxo Atemporal em Cada Detalhe
            </h1>

            {/* Subtitle */}
            <p className="text-stone-300 text-sm sm:text-base leading-relaxed max-w-xl mb-8 font-light">
              Explore uma seleção exclusiva de joalheria fina em ouro 18k, bolsas em couro nobre e perfumaria de nicho. Feito para quem aprecia a verdadeira sofisticação.
            </p>

            {/* CTA Buttons & Interactive Triggers */}
            <div className="flex flex-wrap items-center gap-4">
              <button
                id="btn-hero-explore-catalog"
                onClick={onExploreClick}
                className="flex items-center justify-center gap-2.5 bg-linear-to-r from-amber-400 to-amber-300 hover:from-amber-300 hover:to-amber-200 text-stone-950 font-bold px-7 py-3.5 rounded-full text-xs sm:text-sm tracking-wider uppercase transition-all transform hover:-translate-y-0.5 shadow-lg shadow-amber-950/20"
              >
                <span>Explorar Catálogo Completo</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => onSelectCategory('joias')}
                className="flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 text-white border border-white/20 font-medium px-5 py-3.5 rounded-full text-xs sm:text-sm tracking-wider transition-all backdrop-blur-xs"
              >
                <Gem className="w-4 h-4 text-amber-300" />
                <span>Ver Novas Joias</span>
              </button>
            </div>

            {/* Micro Guarantees in Hero */}
            <div className="grid grid-cols-3 gap-3 pt-8 mt-8 border-t border-white/10 text-[11px] text-stone-300 font-medium">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-300 shrink-0" />
                <span>Garantia Eterna Ouro 18k</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Award className="w-4 h-4 text-amber-300 shrink-0" />
                <span>Artesanato Autoral</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-300 shrink-0" />
                <span>Embalagem Presente VIP</span>
              </div>
            </div>

          </div>

          {/* Right Visual Image Collage with Soft Curved Frames */}
          <div className="lg:col-span-5 p-6 lg:p-10 flex items-center justify-center relative">
            <div className="relative w-full max-w-md">
              
              {/* Main Image Frame with Softened Rounded Corner */}
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border-2 border-amber-400/30 transform lg:rotate-1 hover:rotate-0 transition-transform duration-500">
                <img
                  src="https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=800&q=80"
                  alt="Coleção de Joias Aura Maison"
                  className="w-full h-72 sm:h-84 object-cover object-center"
                />
                <div className="absolute inset-0 bg-linear-to-t from-black/70 via-transparent to-transparent flex items-end p-5">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-widest text-amber-300 block">Destaque da Estação</span>
                    <h3 className="font-serif-luxury text-xl font-bold text-white">Coleção Solitaire D'Or</h3>
                    <p className="text-xs text-stone-200">Em até 10x sem juros</p>
                  </div>
                </div>
              </div>

              {/* Floating Mini Overlay Card */}
              <div className="absolute -bottom-4 -left-4 bg-[#FAF8F5]/95 backdrop-blur-md text-stone-900 p-3 rounded-2xl shadow-xl border border-[#E3D8C6] flex items-center gap-3 animate-bounce duration-1000 hidden sm:flex">
                <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center text-amber-800">
                  <Gem className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[10px] uppercase font-bold text-stone-500 tracking-wider">Certificado</div>
                  <div className="text-xs font-bold text-stone-900">Autenticidade Inclusa</div>
                </div>
              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};

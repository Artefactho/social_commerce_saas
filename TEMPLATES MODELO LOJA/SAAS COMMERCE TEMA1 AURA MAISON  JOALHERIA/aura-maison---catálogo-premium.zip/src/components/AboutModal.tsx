import React from 'react';
import { X, Sparkles, Gem, ShieldCheck, Award, HeartHandshake, PhoneCall } from 'lucide-react';
import { STORE_INFO } from '../data/products';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      
      <div 
        id="about-brand-modal"
        className="relative bg-[#FAF8F5] w-full max-w-2xl rounded-3xl shadow-2xl border border-[#D5C7B0] overflow-hidden my-auto p-6 sm:p-8 animate-in zoom-in-95 duration-200"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2.5 rounded-full bg-white/80 hover:bg-white text-stone-700 hover:text-stone-950 transition-colors shadow-md"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-6">
          <div className="w-16 h-16 rounded-full bg-stone-900 text-amber-200 font-serif text-2xl font-bold flex items-center justify-center mx-auto mb-3 shadow-lg border border-[#D4AF37]">
            AM
          </div>
          <span className="text-xs uppercase tracking-[0.3em] text-amber-800 font-bold">Nossa Essência</span>
          <h2 className="font-serif-luxury text-3xl font-bold text-stone-900 mt-1">
            Aura Maison de Luxe
          </h2>
          <p className="text-xs text-stone-500 mt-1">Fundada com o propósito de unir atemporalidade, ética e arte visual</p>
        </div>

        <div className="space-y-4 text-xs sm:text-sm text-stone-700 leading-relaxed max-h-[60vh] overflow-y-auto pr-1">
          <p>
            A <strong>AURA MAISON</strong> nasceu do desejo de celebrar a elegância autêntica. Cada peça do nosso catálogo — desde as joias em ouro 18k e prata de lei até as bolsas em couro artesanal e fragrâncias raras — é concebida como uma obra de arte duradoura.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <div className="p-4 rounded-2xl bg-[#F3EDE2] border border-[#E5DAC8]">
              <Gem className="w-5 h-5 text-amber-700 mb-1.5" />
              <h4 className="font-serif-luxury font-bold text-stone-900 text-sm">Ouro 18k e Prata 925</h4>
              <p className="text-xs text-stone-600 mt-1">
                Todas as nossas joias acompanham certificado de garantia vitalícia de teor dos metais preciosos e pedrarias.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-[#F3EDE2] border border-[#E5DAC8]">
              <Award className="w-5 h-5 text-amber-700 mb-1.5" />
              <h4 className="font-serif-luxury font-bold text-stone-900 text-sm">Design & Artesanato</h4>
              <p className="text-xs text-stone-600 mt-1">
                Trabalho artesanal com acabamentos manuais minuciosos, costuras italianas e embalagens de alta qualidade.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-[#F0EAE0] border border-[#DDD1BE] text-stone-800 text-xs">
            <h4 className="font-bold text-stone-900 mb-1">Nosso Atelier & Flagship:</h4>
            <p>{STORE_INFO.address}</p>
            <p className="mt-1">Telefone & WhatsApp: <strong>{STORE_INFO.phone}</strong> &bull; E-mail: <strong>{STORE_INFO.email}</strong></p>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-[#EAE2D3] flex flex-wrap items-center justify-between gap-3">
          <a
            href={STORE_INFO.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-xs font-bold text-emerald-800 hover:text-emerald-950 bg-emerald-50 px-4 py-2 rounded-xl border border-emerald-200"
          >
            <PhoneCall className="w-4 h-4 text-emerald-600" />
            <span>Falar com o Concierge</span>
          </a>

          <button
            onClick={onClose}
            className="bg-stone-900 text-amber-200 text-xs font-bold uppercase tracking-wider px-6 py-2.5 rounded-xl hover:bg-stone-800 transition-colors"
          >
            Fechar
          </button>
        </div>

      </div>

    </div>
  );
};

import React from 'react';
import { CheckCircle2, ShoppingBag, Heart, X } from 'lucide-react';
import { ToastNotification } from '../types';

interface ToastProps {
  toast: ToastNotification | null;
  onClose: () => void;
  onOpenCart?: () => void;
}

export const Toast: React.FC<ToastProps> = ({ toast, onClose, onOpenCart }) => {
  if (!toast) return null;

  return (
    <div className="fixed bottom-6 right-4 sm:right-6 z-50 animate-in slide-in-from-bottom-5 duration-300 max-w-sm w-full">
      <div className="bg-[#1C1A17] text-white p-4 rounded-2xl shadow-2xl border border-amber-500/30 flex items-center justify-between gap-3">
        
        {/* Left icon or product thumbnail */}
        <div className="shrink-0">
          {toast.productImage ? (
            <img
              src={toast.productImage}
              alt=""
              className="w-11 h-11 rounded-xl object-cover border border-[#443B31]"
            />
          ) : toast.type === 'cart' ? (
            <div className="w-10 h-10 rounded-xl bg-amber-400/20 text-amber-300 flex items-center justify-center">
              <ShoppingBag className="w-5 h-5" />
            </div>
          ) : (
            <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center">
              <Heart className="w-5 h-5 fill-current" />
            </div>
          )}
        </div>

        {/* Text */}
        <div className="flex-1 min-w-0">
          <h4 className="text-xs font-bold text-amber-200 truncate font-serif">
            {toast.title}
          </h4>
          <p className="text-[11px] text-stone-300 truncate">
            {toast.message}
          </p>
        </div>

        {/* View Cart Button if cart action */}
        {toast.type === 'cart' && onOpenCart && (
          <button
            onClick={() => {
              onClose();
              onOpenCart();
            }}
            className="text-[11px] font-bold text-amber-300 bg-amber-400/10 hover:bg-amber-400/20 px-2.5 py-1.5 rounded-lg border border-amber-400/30 shrink-0 transition-colors"
          >
            Ver Sacola
          </button>
        )}

        {/* Close */}
        <button
          onClick={onClose}
          className="text-stone-400 hover:text-white p-1"
        >
          <X className="w-4 h-4" />
        </button>

      </div>
    </div>
  );
};

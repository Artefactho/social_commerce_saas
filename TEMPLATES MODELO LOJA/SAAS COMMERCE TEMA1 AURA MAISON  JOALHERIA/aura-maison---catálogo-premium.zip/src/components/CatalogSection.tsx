import React from 'react';
import { 
  SlidersHorizontal, 
  Sparkles, 
  ArrowUpDown, 
  X, 
  Layers, 
  Check, 
  Gem, 
  Search 
} from 'lucide-react';
import { Product, SortOption } from '../types';
import { CATEGORIES } from '../data/products';
import { ProductCard } from './ProductCard';

interface CatalogSectionProps {
  products: Product[];
  selectedCategory: string;
  onSelectCategory: (categoryId: string) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  sortBy: SortOption;
  onSortChange: (sort: SortOption) => void;
  onlyPromotions: boolean;
  onTogglePromotions: () => void;
  onAddToCart: (product: Product, color?: string, size?: string) => void;
  onToggleWishlist: (product: Product) => void;
  wishlistIds: string[];
  onQuickView: (product: Product) => void;
}

export const CatalogSection: React.FC<CatalogSectionProps> = ({
  products,
  selectedCategory,
  onSelectCategory,
  searchQuery,
  onSearchChange,
  sortBy,
  onSortChange,
  onlyPromotions,
  onTogglePromotions,
  onAddToCart,
  onToggleWishlist,
  wishlistIds,
  onQuickView
}) => {
  return (
    <section id="catalogo-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8 pb-4 border-b border-[#EAE2D3]">
        <div>
          <div className="flex items-center gap-2 text-amber-800 text-xs font-bold tracking-widest uppercase mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Curadoria Exclusiva</span>
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl font-bold text-stone-900 leading-tight">
            {selectedCategory === 'todos'
              ? 'Catálogo Completo da Maison'
              : CATEGORIES.find((c) => c.id === selectedCategory)?.name || 'Catálogo Selecionado'}
          </h2>
          <p className="text-xs sm:text-sm text-stone-500 mt-1">
            {CATEGORIES.find((c) => c.id === selectedCategory)?.description || 'Peças produzidas em tiragens limitadas.'}
          </p>
        </div>

        {/* Total count badge */}
        <div className="flex items-center gap-2 shrink-0">
          <span className="text-xs font-medium bg-[#F0EAE0] text-stone-700 px-3 py-1.5 rounded-full border border-[#DFD5C2]">
            <strong>{products.length}</strong> {products.length === 1 ? 'item disponível' : 'itens disponíveis'}
          </span>
        </div>
      </div>

      {/* Category Pills Navigation (Rounded Luxury Pills) */}
      <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-6 no-scrollbar">
        {CATEGORIES.map((cat) => {
          const isActive = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold tracking-wide whitespace-nowrap transition-all duration-200 border ${
                isActive
                  ? 'bg-stone-900 text-amber-200 border-stone-900 shadow-md transform scale-105'
                  : 'bg-white text-stone-700 border-[#E5DAC8] hover:border-stone-400 hover:bg-[#FAF6F0]'
              }`}
            >
              <span>{cat.name}</span>
            </button>
          );
        })}
      </div>

      {/* Filters and Sorting Control Bar */}
      <div className="bg-[#FAF7F2] p-3 sm:p-4 rounded-2xl sm:rounded-3xl border border-[#E8DFCFA] mb-8 flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Left: Quick Search in Catalog */}
        <div className="relative w-full md:w-80">
          <input
            type="text"
            placeholder="Filtrar por nome, joia, material..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full text-xs bg-white text-stone-800 placeholder-stone-400 pl-9 pr-8 py-2 rounded-xl border border-[#D8CCB8] focus:outline-hidden focus:border-stone-800"
          />
          <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5 pointer-events-none" />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-2.5 top-2 text-stone-400 hover:text-stone-700 text-xs"
            >
              ✕
            </button>
          )}
        </div>

        {/* Right: Quick toggles and Sort Dropdown */}
        <div className="flex items-center flex-wrap justify-end gap-3 w-full md:w-auto">
          
          {/* Promotions Toggle */}
          <button
            onClick={onTogglePromotions}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
              onlyPromotions
                ? 'bg-rose-50 border-rose-300 text-rose-800'
                : 'bg-white border-[#D8CCB8] text-stone-700 hover:bg-stone-50'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${onlyPromotions ? 'bg-rose-600' : 'bg-stone-300'}`} />
            <span>Apenas com Desconto</span>
          </button>

          {/* Sort Dropdown */}
          <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-xl border border-[#D8CCB8]">
            <ArrowUpDown className="w-3.5 h-3.5 text-stone-500" />
            <span className="text-[11px] text-stone-400 hidden sm:inline">Ordenar:</span>
            <select
              value={sortBy}
              onChange={(e) => onSortChange(e.target.value as SortOption)}
              className="text-xs font-semibold text-stone-800 bg-transparent focus:outline-hidden cursor-pointer"
            >
              <option value="featured">Mais Relevantes</option>
              <option value="price-asc">Menor Preço</option>
              <option value="price-desc">Maior Preço</option>
              <option value="rating">Melhor Avaliados</option>
              <option value="name">Ordem Alfabética</option>
            </select>
          </div>

        </div>

      </div>

      {/* Active Filter Badges */}
      {(searchQuery || selectedCategory !== 'todos' || onlyPromotions) && (
        <div className="flex items-center flex-wrap gap-2 mb-6 text-xs text-stone-600">
          <span className="font-semibold text-[11px] text-stone-400">Filtros ativos:</span>

          {selectedCategory !== 'todos' && (
            <span className="inline-flex items-center gap-1 bg-[#F0E8DC] text-stone-800 px-3 py-1 rounded-full border border-[#D8CCB8]">
              Categoria: {CATEGORIES.find((c) => c.id === selectedCategory)?.name}
              <button onClick={() => onSelectCategory('todos')} className="hover:text-stone-950 font-bold ml-1">✕</button>
            </span>
          )}

          {searchQuery && (
            <span className="inline-flex items-center gap-1 bg-[#F0E8DC] text-stone-800 px-3 py-1 rounded-full border border-[#D8CCB8]">
              Busca: "{searchQuery}"
              <button onClick={() => onSearchChange('')} className="hover:text-stone-950 font-bold ml-1">✕</button>
            </span>
          )}

          {onlyPromotions && (
            <span className="inline-flex items-center gap-1 bg-rose-100 text-rose-800 px-3 py-1 rounded-full border border-rose-200">
              Com Desconto
              <button onClick={onTogglePromotions} className="hover:text-rose-950 font-bold ml-1">✕</button>
            </span>
          )}

          <button
            onClick={() => {
              onSelectCategory('todos');
              onSearchChange('');
              if (onlyPromotions) onTogglePromotions();
            }}
            className="text-[11px] text-stone-500 hover:text-stone-900 underline ml-2"
          >
            Limpar todos os filtros
          </button>
        </div>
      )}

      {/* Products Grid */}
      {products.length === 0 ? (
        <div className="bg-[#FAF7F2] rounded-3xl p-12 text-center border border-[#E8DFCFA] space-y-4">
          <div className="w-16 h-16 rounded-full bg-[#EFE8DC] flex items-center justify-center mx-auto text-stone-400">
            <Search className="w-8 h-8" />
          </div>
          <h3 className="font-serif-luxury text-2xl font-bold text-stone-900">
            Nenhum produto encontrado
          </h3>
          <p className="text-xs text-stone-500 max-w-sm mx-auto">
            Não encontramos peças com os critérios de busca especificados. Tente remover filtros ou buscar por outro termo.
          </p>
          <button
            onClick={() => {
              onSelectCategory('todos');
              onSearchChange('');
              if (onlyPromotions) onTogglePromotions();
            }}
            className="bg-stone-900 text-amber-200 text-xs font-bold uppercase tracking-wider px-6 py-2.5 rounded-full shadow-md hover:bg-stone-800"
          >
            Ver Catálogo Completo
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5 sm:gap-6">
          {products.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onAddToCart={onAddToCart}
              onToggleWishlist={onToggleWishlist}
              isWishlisted={wishlistIds.includes(product.id)}
              onQuickView={onQuickView}
            />
          ))}
        </div>
      )}

    </section>
  );
};

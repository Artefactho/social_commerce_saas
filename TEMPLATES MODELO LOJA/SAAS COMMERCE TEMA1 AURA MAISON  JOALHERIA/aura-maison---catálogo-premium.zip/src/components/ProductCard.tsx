import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Heart, 
  Eye, 
  Star, 
  Check, 
  Sparkles, 
  ArrowUpRight 
} from 'lucide-react';
import { Product } from '../types';
import { formatCurrency } from '../data/products';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product, color?: string, size?: string) => void;
  onToggleWishlist: (product: Product) => void;
  isWishlisted: boolean;
  onQuickView: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onAddToCart,
  onToggleWishlist,
  isWishlisted,
  onQuickView
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [addedAnimation, setAddedAnimation] = useState(false);
  const [selectedColor, setSelectedColor] = useState<string | undefined>(
    product.colors?.[0]?.name
  );

  const installmentCount = 10;
  const installmentValue = product.price / installmentCount;

  const handleAddClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product, selectedColor, product.sizes?.[0]);
    setAddedAnimation(true);
    setTimeout(() => setAddedAnimation(false), 1400);
  };

  const getBadgeStyle = (type?: string) => {
    switch (type) {
      case 'gold':
        return 'bg-amber-400/90 text-stone-950 font-bold border-amber-500/40 shadow-xs';
      case 'emerald':
        return 'bg-emerald-700 text-emerald-50 font-semibold border-emerald-800 shadow-xs';
      case 'red':
        return 'bg-rose-700 text-white font-bold border-rose-800 shadow-xs';
      default:
        return 'bg-stone-900/90 text-amber-200 font-bold border-stone-800 shadow-xs';
    }
  };

  return (
    <div
      id={`product-card-${product.id}`}
      className="group relative bg-[#FAF8F5] rounded-2xl sm:rounded-3xl border border-[#E8E0D2] overflow-hidden flex flex-col justify-between transition-all duration-300 hover:shadow-xl hover:border-[#D1C3AD] hover:-translate-y-1"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Top Image Container */}
      <div className="relative aspect-square w-full overflow-hidden bg-[#F2EDE4] cursor-pointer" onClick={() => onQuickView(product)}>
        
        {/* Main Product Image with subtle hover zoom */}
        <img
          src={isHovered && product.images[1] ? product.images[1] : product.images[0]}
          alt={product.name}
          loading="lazy"
          className="w-full h-full object-cover object-center transition-all duration-500 transform group-hover:scale-105"
        />

        {/* Top Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10">
          {product.badge && (
            <span className={`text-[10px] uppercase tracking-wider px-2.5 py-1 rounded-full border backdrop-blur-xs ${getBadgeStyle(product.badgeType)}`}>
              {product.badge}
            </span>
          )}
          {product.originalPrice && (
            <span className="text-[10px] font-bold bg-rose-600 text-white px-2 py-0.5 rounded-full w-fit shadow-xs">
              -{Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
            </span>
          )}
        </div>

        {/* Floating Quick Action Buttons (Wishlist & Quick View) */}
        <div className="absolute top-3 right-3 flex flex-col gap-2 z-10">
          {/* Wishlist Button */}
          <button
            id={`btn-wishlist-${product.id}`}
            onClick={(e) => {
              e.stopPropagation();
              onToggleWishlist(product);
            }}
            className={`p-2 rounded-full backdrop-blur-md transition-all duration-200 shadow-md ${
              isWishlisted
                ? 'bg-rose-50 text-rose-600 border border-rose-200 ring-2 ring-rose-300'
                : 'bg-white/80 text-stone-700 hover:text-rose-600 hover:bg-white border border-white/60'
            }`}
            title={isWishlisted ? "Remover dos favoritos" : "Salvar nos favoritos"}
            aria-label="Favoritar produto"
          >
            <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
          </button>

          {/* Quick View Button */}
          <button
            id={`btn-quickview-${product.id}`}
            onClick={(e) => {
              e.stopPropagation();
              onQuickView(product);
            }}
            className="p-2 rounded-full bg-white/80 hover:bg-white text-stone-700 hover:text-stone-950 backdrop-blur-md border border-white/60 transition-all duration-200 shadow-md hidden sm:flex items-center justify-center opacity-90 group-hover:opacity-100"
            title="Visualização rápida"
            aria-label="Ver detalhes rápidos"
          >
            <Eye className="w-4 h-4" />
          </button>
        </div>

        {/* Low Stock Warning Badge */}
        {product.stockCount <= 5 && product.stockCount > 0 && (
          <div className="absolute bottom-2 left-2 z-10 bg-amber-950/80 text-amber-200 text-[10px] font-medium px-2 py-0.5 rounded-md backdrop-blur-xs">
            Restam apenas {product.stockCount} un.
          </div>
        )}
      </div>

      {/* Product Content Body */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
        
        <div>
          {/* Category & Rating */}
          <div className="flex items-center justify-between text-xs text-stone-500 mb-1.5">
            <span className="uppercase tracking-wider text-[10px] font-semibold text-amber-800">
              {product.category}
            </span>
            <div className="flex items-center gap-1 text-stone-600">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span className="font-semibold text-[11px] text-stone-800">{product.rating.toFixed(1)}</span>
              <span className="text-[10px] text-stone-400">({product.reviewsCount})</span>
            </div>
          </div>

          {/* Product Title */}
          <h3 
            onClick={() => onQuickView(product)}
            className="font-serif-luxury text-base sm:text-lg font-bold text-stone-900 leading-snug line-clamp-2 cursor-pointer hover:text-amber-800 transition-colors mb-2"
          >
            {product.name}
          </h3>

          {/* Color Selection preview if available */}
          {product.colors && product.colors.length > 0 && (
            <div className="flex items-center gap-1.5 my-2">
              {product.colors.map((c) => (
                <button
                  key={c.name}
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedColor(c.name);
                  }}
                  className={`w-3.5 h-3.5 rounded-full border transition-all ${
                    selectedColor === c.name 
                      ? 'ring-2 ring-amber-700 ring-offset-1 scale-110' 
                      : 'border-stone-300 opacity-70 hover:opacity-100'
                  }`}
                  style={{ backgroundColor: c.hex }}
                  title={c.name}
                />
              ))}
              <span className="text-[10px] text-stone-500 ml-1 truncate">
                {selectedColor || product.colors[0].name}
              </span>
            </div>
          )}
        </div>

        {/* Pricing and Action Section */}
        <div className="pt-3 border-t border-[#EAE3D6] mt-3">
          
          {/* Price Block */}
          <div className="mb-3">
            <div className="flex items-baseline gap-2">
              <span className="text-base sm:text-lg font-extrabold text-stone-900 tracking-tight">
                {formatCurrency(product.price)}
              </span>
              {product.originalPrice && (
                <span className="text-xs text-stone-400 line-through">
                  {formatCurrency(product.originalPrice)}
                </span>
              )}
            </div>
            <div className="text-[11px] text-emerald-800 font-medium flex items-center gap-1 mt-0.5">
              <span>ou <strong>10x</strong> de <strong>{formatCurrency(installmentValue)}</strong> sem juros</span>
            </div>
          </div>

          {/* Add to Cart Action Button with Rounded Pill Design */}
          <button
            id={`btn-add-to-cart-${product.id}`}
            onClick={handleAddClick}
            disabled={!product.inStock}
            className={`w-full py-2.5 px-4 rounded-xl sm:rounded-2xl text-xs font-bold tracking-wider uppercase transition-all duration-200 flex items-center justify-center gap-2 shadow-xs ${
              addedAnimation
                ? 'bg-emerald-700 text-white'
                : product.inStock
                ? 'bg-[#1E1B18] hover:bg-[#332E29] text-[#FAF8F5] active:scale-[0.98]'
                : 'bg-stone-200 text-stone-400 cursor-not-allowed'
            }`}
          >
            {addedAnimation ? (
              <>
                <Check className="w-4 h-4 text-emerald-300 animate-bounce" />
                <span>Adicionado!</span>
              </>
            ) : product.inStock ? (
              <>
                <ShoppingBag className="w-3.5 h-3.5 text-amber-300" />
                <span>Adicionar ao Carrinho</span>
              </>
            ) : (
              <span>Esgotado</span>
            )}
          </button>

        </div>

      </div>
    </div>
  );
};

import React, { useState, useEffect, useMemo } from 'react';
import { Product, CartItem, SortOption, ToastNotification } from './types';
import { PRODUCTS } from './data/products';
import { TopBanner } from './components/TopBanner';
import { Header } from './components/Header';
import { HeroCatalogBanner } from './components/HeroCatalogBanner';
import { CatalogSection } from './components/CatalogSection';
import { FeaturesBar } from './components/FeaturesBar';
import { ProductModal } from './components/ProductModal';
import { CartDrawer } from './components/CartDrawer';
import { WishlistDrawer } from './components/WishlistDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { AboutModal } from './components/AboutModal';
import { Footer } from './components/Footer';
import { Toast } from './components/Toast';

export default function App() {
  // Persistence for Cart and Wishlist
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('aura_cart_items');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [wishlist, setWishlist] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('aura_wishlist_items');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Filter & Navigation State
  const [selectedCategory, setSelectedCategory] = useState<string>('todos');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<SortOption>('featured');
  const [onlyPromotions, setOnlyPromotions] = useState<boolean>(false);

  // Modals & Drawers
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState<boolean>(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState<boolean>(false);
  const [isAboutOpen, setIsAboutOpen] = useState<boolean>(false);
  const [appliedCoupon, setAppliedCoupon] = useState<string | undefined>(undefined);
  const [discountAmount, setDiscountAmount] = useState<number>(0);
  const [toast, setToast] = useState<ToastNotification | null>(null);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('aura_cart_items', JSON.stringify(cartItems));
  }, [cartItems]);

  useEffect(() => {
    localStorage.setItem('aura_wishlist_items', JSON.stringify(wishlist));
  }, [wishlist]);

  // Toast Helper
  const showToast = (title: string, message: string, type: 'cart' | 'info' = 'cart', image?: string) => {
    setToast({
      id: String(Date.now()),
      title,
      message,
      type,
      productImage: image
    });
    setTimeout(() => {
      setToast((prev) => (prev?.title === title ? null : prev));
    }, 3500);
  };

  // Cart Handlers
  const handleAddToCart = (product: Product, color?: string, size?: string, quantity: number = 1) => {
    const itemUniqueId = `${product.id}-${color || 'default'}-${size || 'default'}`;
    
    setCartItems((prev) => {
      const existing = prev.find((item) => item.id === itemUniqueId);
      if (existing) {
        return prev.map((item) =>
          item.id === itemUniqueId
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [
        ...prev,
        {
          id: itemUniqueId,
          product,
          quantity,
          selectedColor: color,
          selectedSize: size
        }
      ];
    });

    showToast(
      'Adicionado à Sacola!',
      `${quantity}x ${product.name}`,
      'cart',
      product.images[0]
    );
  };

  const handleUpdateCartQuantity = (id: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.id === id) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveCartItem = (id: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== id));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  // Wishlist Handlers
  const handleToggleWishlist = (product: Product) => {
    setWishlist((prev) => {
      const exists = prev.some((p) => p.id === product.id);
      if (exists) {
        showToast('Removido dos Favoritos', product.name, 'info');
        return prev.filter((p) => p.id !== product.id);
      } else {
        showToast('Salvo nos Favoritos', product.name, 'info', product.images[0]);
        return [...prev, product];
      }
    });
  };

  const handleMoveWishlistToCart = (product: Product) => {
    handleAddToCart(product);
    setWishlist((prev) => prev.filter((p) => p.id !== product.id));
  };

  // Checkout Handlers
  const handleOpenCheckout = (coupon?: string, discount: number = 0) => {
    setAppliedCoupon(coupon);
    setDiscountAmount(discount);
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const handleOrderSuccess = () => {
    setCartItems([]);
  };

  // Filtered & Sorted Products
  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter((product) => {
      // Category filter
      if (selectedCategory !== 'todos' && product.category !== selectedCategory) {
        return false;
      }
      // Promotions only
      if (onlyPromotions && !product.originalPrice) {
        return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesName = product.name.toLowerCase().includes(query);
        const matchesDesc = product.description.toLowerCase().includes(query);
        const matchesSku = product.sku.toLowerCase().includes(query);
        const matchesCat = product.category.toLowerCase().includes(query);
        if (!matchesName && !matchesDesc && !matchesSku && !matchesCat) {
          return false;
        }
      }
      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      // 'featured'
      if (a.isFeatured && !b.isFeatured) return -1;
      if (!a.isFeatured && b.isFeatured) return 1;
      return 0;
    });
  }, [selectedCategory, searchQuery, sortBy, onlyPromotions]);

  const totalCartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);
  const wishlistIds = wishlist.map((p) => p.id);

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F5] text-stone-800 font-sans selection:bg-amber-200">
      
      {/* 1. Narrow Top Announcement Banner */}
      <TopBanner />

      {/* 2. Main Header with Centered Round Logo & 3 Menus */}
      <Header
        cartCount={totalCartCount}
        wishlistCount={wishlist.length}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onSelectCategory={(catId) => setSelectedCategory(catId)}
        selectedCategory={selectedCategory}
        searchQuery={searchQuery}
        onSearchChange={(q) => setSearchQuery(q)}
        onOpenAbout={() => setIsAboutOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        
        {/* 3. Hero Luxury Catalog Banner with Rounded Curves */}
        <HeroCatalogBanner
          onExploreClick={() => {
            const el = document.getElementById('catalogo-section');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          onSelectCategory={(catId) => {
            setSelectedCategory(catId);
            const el = document.getElementById('catalogo-section');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        {/* 4. Trust & Guarantees Bar */}
        <FeaturesBar />

        {/* 5. Main Catalog Product Grid with Filters & Sorting */}
        <CatalogSection
          products={filteredProducts}
          selectedCategory={selectedCategory}
          onSelectCategory={(catId) => setSelectedCategory(catId)}
          searchQuery={searchQuery}
          onSearchChange={(q) => setSearchQuery(q)}
          sortBy={sortBy}
          onSortChange={(s) => setSortBy(s)}
          onlyPromotions={onlyPromotions}
          onTogglePromotions={() => setOnlyPromotions(!onlyPromotions)}
          onAddToCart={handleAddToCart}
          onToggleWishlist={handleToggleWishlist}
          wishlistIds={wishlistIds}
          onQuickView={(p) => setSelectedProduct(p)}
        />

      </main>

      {/* 6. Footer with 3 Navigation Pillars, Newsletter and Guarantees */}
      <Footer
        onSelectCategory={(catId) => {
          setSelectedCategory(catId);
          window.scrollTo({ top: 400, behavior: 'smooth' });
        }}
        onOpenAbout={() => setIsAboutOpen(true)}
      />

      {/* Product Detail Modal */}
      <ProductModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
        onToggleWishlist={handleToggleWishlist}
        isWishlisted={selectedProduct ? wishlistIds.includes(selectedProduct.id) : false}
      />

      {/* Cart Slide-Over Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
        onOpenCheckout={handleOpenCheckout}
      />

      {/* Wishlist Drawer */}
      <WishlistDrawer
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        items={wishlist}
        onRemoveFromWishlist={handleToggleWishlist}
        onMoveToCart={handleMoveWishlistToCart}
        onClearWishlist={() => setWishlist([])}
      />

      {/* Checkout Simulator Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        items={cartItems}
        couponCode={appliedCoupon}
        discountAmount={discountAmount}
        onSuccessOrder={handleOrderSuccess}
      />

      {/* About Maison Modal */}
      <AboutModal
        isOpen={isAboutOpen}
        onClose={() => setIsAboutOpen(false)}
      />

      {/* Floating Action Toast Notification */}
      <Toast
        toast={toast}
        onClose={() => setToast(null)}
        onOpenCart={() => setIsCartOpen(true)}
      />

    </div>
  );
}

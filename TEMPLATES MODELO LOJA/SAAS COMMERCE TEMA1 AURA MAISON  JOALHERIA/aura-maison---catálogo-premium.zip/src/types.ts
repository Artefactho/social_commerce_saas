export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewsCount: number;
  description: string;
  shortDescription: string;
  images: string[];
  inStock: boolean;
  stockCount: number;
  badge?: string;
  badgeType?: 'gold' | 'dark' | 'red' | 'emerald';
  colors?: { name: string; hex: string }[];
  sizes?: string[];
  sku: string;
  isFeatured?: boolean;
  material?: string;
  dimensions?: string;
}

export interface CartItem {
  id: string;
  product: Product;
  quantity: number;
  selectedColor?: string;
  selectedSize?: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  image: string;
  description: string;
}

export type SortOption = 'featured' | 'price-asc' | 'price-desc' | 'rating' | 'name';

export interface FilterState {
  search: string;
  category: string;
  sort: SortOption;
  minPrice: number;
  maxPrice: number;
  onlyInStock: boolean;
  onlyPromotions: boolean;
}

export interface ToastNotification {
  id: string;
  title: string;
  message: string;
  type?: 'success' | 'info' | 'cart';
  productImage?: string;
}

export interface OrderDetails {
  customerName: string;
  email: string;
  phone: string;
  cpf: string;
  cep: string;
  street: string;
  number: string;
  complement?: string;
  neighborhood: string;
  city: string;
  state: string;
  paymentMethod: 'pix' | 'credit_card' | 'boleto';
  installments?: number;
  couponCode?: string;
  discountAmount: number;
  subtotal: number;
  shipping: number;
  total: number;
  items: CartItem[];
  orderNumber: string;
  orderDate: string;
}

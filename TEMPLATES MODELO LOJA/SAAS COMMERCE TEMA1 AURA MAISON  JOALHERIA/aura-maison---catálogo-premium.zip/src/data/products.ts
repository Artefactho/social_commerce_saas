import { Product, Category } from '../types';

export const CATEGORIES: Category[] = [
  {
    id: 'todos',
    name: 'Todos os Produtos',
    slug: 'todos',
    image: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=600&q=80',
    description: 'Navegue por todo o catálogo exclusivo da Maison'
  },
  {
    id: 'joias',
    name: 'Joalheria & Acessórios',
    slug: 'joias',
    image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=600&q=80',
    description: 'Ouro 18k, prata 925 e pedras naturais selecionadas'
  },
  {
    id: 'bolsas',
    name: 'Bolsas & Couro',
    slug: 'bolsas',
    image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=600&q=80',
    description: 'Design atemporal confeccionado em couro legítimo premium'
  },
  {
    id: 'perfumaria',
    name: 'Perfumaria & Velas',
    slug: 'perfumaria',
    image: 'https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=600&q=80',
    description: 'Fragrâncias de nicho e essências botânicas nobres'
  },
  {
    id: 'vestuario',
    name: 'Vestuário & Seda',
    slug: 'vestuario',
    image: 'https://images.unsplash.com/photo-1485968579580-b6d095142e6e?auto=format&fit=crop&w=600&q=80',
    description: 'Linho puro, seda pura e alfaiataria contemporânea'
  },
  {
    id: 'decor',
    name: 'Casa & Decoração',
    slug: 'decor',
    image: 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&w=600&q=80',
    description: 'Objetos esculturais, cerâmicas e design autoral'
  }
];

export const PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    name: 'Colar Aura Solitário Ouro 18k',
    category: 'joias',
    price: 890.0,
    originalPrice: 1050.0,
    rating: 4.9,
    reviewsCount: 42,
    shortDescription: 'Colar com corrente veneziana delicada e pingente ponto de luz em ouro 18k com zircônia cravejada.',
    description: 'Uma joia atemporal forjada em ouro amarelo 18k com acabamento polido de alto brilho. O pingente central captura a luz em todas as direções, conferindo sofisticação minimalista a qualquer composição diária ou noturna.',
    images: [
      'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1611591475102-4fa8353ab465?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=800&q=80'
    ],
    inStock: true,
    stockCount: 8,
    badge: 'DESTAQUE',
    badgeType: 'gold',
    sku: 'AM-J01-SOL',
    isFeatured: true,
    material: 'Ouro 18k legítimo (750)',
    dimensions: 'Corrente 45cm ajustável',
    colors: [
      { name: 'Ouro Amarelo', hex: '#D4AF37' },
      { name: 'Ouro Branco', hex: '#E5E4E2' },
      { name: 'Ouro Rosé', hex: '#B76E79' }
    ]
  },
  {
    id: 'prod-2',
    name: 'Bolsa Estruturada Riviera em Couro',
    category: 'bolsas',
    price: 1420.0,
    originalPrice: 1680.0,
    rating: 5.0,
    reviewsCount: 28,
    shortDescription: 'Bolsa estruturada confeccionada artesanalmente em couro italiano floater macio.',
    description: 'Inspirada na elegância da costa mediterrânea, a Bolsa Riviera combina estrutura geométrica precisa com a maleabilidade do couro nobre. Ferragens banhadas em ouro champagne fosco e interior forrado em camurça aveludada.',
    images: [
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=800&q=80'
    ],
    inStock: true,
    stockCount: 5,
    badge: 'BEST SELLER',
    badgeType: 'emerald',
    sku: 'AM-B02-RIV',
    isFeatured: true,
    material: 'Couro Bovino Legítimo Grão Inteiro',
    dimensions: '28cm x 20cm x 11cm',
    colors: [
      { name: 'Caramelo Toffee', hex: '#8B4513' },
      { name: 'Preto Noir', hex: '#1C1917' },
      { name: 'Off-White Créme', hex: '#F5F5DC' }
    ]
  },
  {
    id: 'prod-3',
    name: 'Eau de Parfum Nuit Blanche 100ml',
    category: 'perfumaria',
    price: 490.0,
    originalPrice: undefined,
    rating: 4.8,
    reviewsCount: 64,
    shortDescription: 'Notas de âmbar cinzento, baunilha de Madagascar, sândalo e pétalas de jasmim noturno.',
    description: 'Fragrância autoral assinada por mestres perfumistas de Grasse. Uma fusão magnética de madeiras nobres, resinas quentes e a delicadeza hipnótica das flores brancas colhidas ao entardecer.',
    images: [
      'https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1523293182086-7651a899d37f?auto=format&fit=crop&w=800&q=80'
    ],
    inStock: true,
    stockCount: 14,
    badge: 'EXCLUSIVO',
    badgeType: 'gold',
    sku: 'AM-P03-NBL',
    isFeatured: true,
    material: 'Frasco em Vidro Cristalino com Tampa Magnética',
    dimensions: '100 ml / 3.4 fl. oz.',
    sizes: ['50ml', '100ml']
  },
  {
    id: 'prod-4',
    name: 'Camisa Oversized em Linho Puro',
    category: 'vestuario',
    price: 580.0,
    originalPrice: 650.0,
    rating: 4.9,
    reviewsCount: 31,
    shortDescription: 'Linho 100% europeu pré-lavado, caimento fluido e botões em madrepérola natural.',
    description: 'Confeccionada com linho de gramatura média e toque macio aveludado obtido pelo processo exclusivo de amaciamento enzimático. Silhueta descontraída e sofisticada que transita entre dias ensolarados e noites amenas.',
    images: [
      'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=800&q=80'
    ],
    inStock: true,
    stockCount: 9,
    badge: 'NOVA COLEÇÃO',
    badgeType: 'dark',
    sku: 'AM-V04-LIN',
    isFeatured: true,
    material: '100% Linho Francês Puro',
    sizes: ['PP', 'P', 'M', 'G', 'GG'],
    colors: [
      { name: 'Areia Natural', hex: '#E6D7C3' },
      { name: 'Branco Puro', hex: '#FAFAFA' },
      { name: 'Azul Névoa', hex: '#778899' }
    ]
  },
  {
    id: 'prod-5',
    name: 'Vaso Escultórico Luna em Cerâmica Artesanal',
    category: 'decor',
    price: 380.0,
    originalPrice: 440.0,
    rating: 4.7,
    reviewsCount: 19,
    shortDescription: 'Peça moldada à mão com argila crua e acabamento fosco texturizado mineral.',
    description: 'Cada peça carrega a singularidade do gesto manual do artesão ceramista. Formas orgânicas com abertura em arco contemporâneo, perfeita para arranjos secos de eucalipto, capim dos pampas ou como escultura de destaque.',
    images: [
      'https://images.unsplash.com/photo-1612196808214-b8e1d6145a8c?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=800&q=80'
    ],
    inStock: true,
    stockCount: 6,
    badge: 'AUTORAL',
    badgeType: 'emerald',
    sku: 'AM-D05-LUN',
    isFeatured: false,
    material: 'Cerâmica Terracota Mineral Queimada em Alta Temperatura',
    dimensions: '26cm Altura x 18cm Largura'
  },
  {
    id: 'prod-6',
    name: 'Brinco Argola Riviera Cravejada',
    category: 'joias',
    price: 720.0,
    originalPrice: undefined,
    rating: 5.0,
    reviewsCount: 53,
    shortDescription: 'Par de argolas médias em prata de lei 925 com banho triplo de ródio e zircônias corte brilhante.',
    description: 'O equilíbrio sublime entre discrição e brilho arrebatador. Sistema de fechamento click anatômico super confortável para uso contínuo sem pressão no lóbulo.',
    images: [
      'https://images.unsplash.com/photo-1630019852942-f89202989a59?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=800&q=80'
    ],
    inStock: true,
    stockCount: 11,
    badge: 'POPULAR',
    badgeType: 'gold',
    sku: 'AM-J06-ARG',
    isFeatured: true,
    material: 'Prata 925 com Banho de Ródio Branco',
    dimensions: 'Diâmetro 22mm / Espessura 3mm'
  },
  {
    id: 'prod-7',
    name: 'Vela Aromática Botanique 240g em Vidro Fumê',
    category: 'perfumaria',
    price: 180.0,
    originalPrice: 210.0,
    rating: 4.9,
    reviewsCount: 88,
    shortDescription: 'Cera 100% vegetal de coco, pavio duplo de algodão e aroma calmante de figo e cedro.',
    description: 'Tempo de queima aproximado de 50 horas contínuas. Queima limpa e perfumação gradual de ambientes amplos. Apresentada em pote reutilizável de vidro fumê com tampa em madeira nobre gravada a laser.',
    images: [
      'https://images.unsplash.com/photo-1603006905003-be475563bc59?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?auto=format&fit=crop&w=800&q=80'
    ],
    inStock: true,
    stockCount: 22,
    badge: 'ORGANIC',
    badgeType: 'emerald',
    sku: 'AM-P07-VEL',
    isFeatured: false,
    material: 'Cera de Coco e Palma com Essência Pura',
    dimensions: '9cm Altura x 8cm Diâmetro (240g)'
  },
  {
    id: 'prod-8',
    name: 'Porta-Cartões Minimalista em Couro Croco',
    category: 'bolsas',
    price: 290.0,
    originalPrice: 340.0,
    rating: 4.8,
    reviewsCount: 37,
    shortDescription: 'Textura prensada em alto relevo, 4 slots para cartões e compartimento central.',
    description: 'Design ultrafino concebido para caber confortavelmente em qualquer bolso ou clutch sem criar volume. Acabamento de borda italiana selada manualmente.',
    images: [
      'https://images.unsplash.com/photo-1627123424574-724758594e93?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80'
    ],
    inStock: true,
    stockCount: 15,
    badge: 'PRESENTE IDEAL',
    badgeType: 'dark',
    sku: 'AM-B08-CAR',
    isFeatured: false,
    material: 'Couro Bovino com Estampa Croco',
    dimensions: '10cm x 7.5cm',
    colors: [
      { name: 'Verde Floresta', hex: '#1E3F20' },
      { name: 'Preto Ébano', hex: '#1C1917' },
      { name: 'Bordeaux Nobre', hex: '#5C1D24' }
    ]
  },
  {
    id: 'prod-9',
    name: 'Vestido Midi Slip Dress em Seda Mulberry',
    category: 'vestuario',
    price: 980.0,
    originalPrice: 1190.0,
    rating: 5.0,
    reviewsCount: 17,
    shortDescription: 'Seda pura 19 momme, caimento enviesado fluido e alças finas reguláveis.',
    description: 'O clássico vestido slip contemporâneo cortado no viés para abraçar suavemente a silhueta com movimento gracioso. Toque refrescante, hipoalergênico e brilho acetinado natural.',
    images: [
      'https://images.unsplash.com/photo-1568252542512-9fe8fe9c87bb?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=800&q=80'
    ],
    inStock: true,
    stockCount: 4,
    badge: 'LUXO',
    badgeType: 'gold',
    sku: 'AM-V09-SLP',
    isFeatured: true,
    material: '100% Seda Pura Mulberry Grau 6A',
    sizes: ['PP', 'P', 'M', 'G'],
    colors: [
      { name: 'Champagne Perolado', hex: '#F7E7CE' },
      { name: 'Verde Oliva Escuro', hex: '#3B443B' },
      { name: 'Preto Clássico', hex: '#111111' }
    ]
  },
  {
    id: 'prod-10',
    name: 'Bandeja Orgânica em Mármore Travertino',
    category: 'decor',
    price: 460.0,
    originalPrice: undefined,
    rating: 4.9,
    reviewsCount: 24,
    shortDescription: 'Mármore natural usinado e polido com bordas suaves e pés em veludo protetor.',
    description: 'Elemento multifuncional para compor mesas de centro, toucadores de perfumes e joias ou mesas de cabeceira. As ranhuras naturais da rocha conferem caráter único a cada exemplar.',
    images: [
      'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&w=800&q=80'
    ],
    inStock: true,
    stockCount: 7,
    badge: 'DESIGN AUTORAL',
    badgeType: 'emerald',
    sku: 'AM-D10-MAR',
    isFeatured: false,
    material: 'Mármore Travertino Romano Natural',
    dimensions: '30cm x 18cm x 2.5cm'
  }
];

export const PROMO_COUPONS: Record<string, number> = {
  'AURA5': 0.05,
  'PRIMEIRACOMPRA': 0.10,
  'BEMVINDO10': 0.10,
  'MAISON15': 0.15
};

export const STORE_INFO = {
  name: 'AURA MAISON',
  slogan: 'Haute Joaillerie & Curadoria de Estilo',
  phone: '(11) 98765-4321',
  whatsappUrl: 'https://wa.me/5511987654321',
  email: 'concierge@auramaison.com.br',
  address: 'Alameda Gabriel Monteiro da Silva, 1420 — Jardins, São Paulo - SP',
  freeShippingThreshold: 350.0,
  defaultShippingCost: 28.0,
  instagram: '@auramaison.oficial'
};

export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(value);
}

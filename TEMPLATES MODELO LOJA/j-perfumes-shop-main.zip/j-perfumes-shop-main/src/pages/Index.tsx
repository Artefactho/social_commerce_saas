import { useState } from "react";
import StoreHeader from "@/components/store/store-header";
import HeroCarousel from "@/components/store/hero-carousel";
import StoreProfile from "@/components/store/store-profile";
import StoryHighlights from "@/components/store/story-highlights";
import ProductGrid, { type Product } from "@/components/store/product-grid";
import StoreFooter from "@/components/store/store-footer";
import BottomNav from "@/components/store/bottom-nav";
import SideMenu from "@/components/store/side-menu";

import heroBanner from "@/assets/hero-banner.jpg";
import product1 from "@/assets/product-1.jpg";
import product2 from "@/assets/product-2.jpg";
import product3 from "@/assets/product-3.jpg";
import product4 from "@/assets/product-4.jpg";
import product5 from "@/assets/product-5.jpg";
import product6 from "@/assets/product-6.jpg";

const carouselSlides = [
  {
    image: heroBanner,
    title: "Nova Coleção 2026",
    subtitle: "Descubra fragrâncias que contam a sua história",
    ctaText: "Ver Coleção",
  },
  {
    image: product3,
    title: "Noir Absolu",
    subtitle: "Elegância atemporal em cada nota",
    ctaText: "Explorar",
  },
  {
    image: product5,
    title: "Essências Exclusivas",
    subtitle: "Seleção premium para momentos especiais",
    ctaText: "Descobrir",
  },
];

const sampleProducts: Product[] = [
  { id: "1", name: "Âmbar Dourado EDP", price: 189.9, originalPrice: 249.9, image: product1 },
  { id: "2", name: "Rosa Delicata EDP", price: 159.9, image: product2, isNew: true },
  { id: "3", name: "Noir Absolu EDP", price: 219.9, image: product3 },
  { id: "4", name: "Lavanda Provence EDT", price: 129.9, originalPrice: 169.9, image: product4 },
  { id: "5", name: "Gold Essence EDP", price: 279.9, image: product5, isNew: true },
  { id: "6", name: "Rouge Passion EDP", price: 199.9, image: product6, isSoldOut: true },
  { id: "7", name: "Brisa do Mar EDT", price: 139.9, originalPrice: 179.9, image: product1 },
  { id: "8", name: "Fleur Noire EDP", price: 249.9, image: product3, isNew: true },
];

const Index = () => {
  const [cartCount, setCartCount] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);

  const handleAddToCart = (_product: Product) => {
    setCartCount((prev) => prev + 1);
  };

  return (
    <div className="min-h-screen bg-background">
      <SideMenu open={menuOpen} onClose={() => setMenuOpen(false)} />
      <StoreHeader cartCount={cartCount} onMenuClick={() => setMenuOpen(true)} />
      <main className="pb-20 md:pb-0">
        <HeroCarousel slides={carouselSlides} />
        <StoreProfile />
        <StoryHighlights />
        <ProductGrid products={sampleProducts} onAddToCart={handleAddToCart} />
      </main>
      <StoreFooter />
      <BottomNav cartCount={cartCount} />
    </div>
  );
};

export default Index;

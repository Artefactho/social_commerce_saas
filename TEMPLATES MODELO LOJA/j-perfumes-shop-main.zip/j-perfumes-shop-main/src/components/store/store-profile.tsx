import { useState } from "react";
import { MapPin, Globe, Mail, Phone, Tag, ChevronDown, ChevronUp, Verified } from "lucide-react";

interface StoreProfileProps {
  storeName?: string;
  logo?: string;
  category?: string;
  bio?: string;
  email?: string;
  phone?: string;
  address?: string;
  website?: string;
  domain?: string;
  postsCount?: number;
  followersCount?: string;
  followingCount?: number;
}

const StoreProfile = ({
  storeName = "JÔ Perfumes",
  logo,
  category = "Perfumaria & Cosméticos",
  bio = "✨ Fragrâncias exclusivas para todos os momentos\n🌹 Qualidade e sofisticação em cada frasco\n📦 Entrega para todo o Brasil\n💎 Desde 2020",
  email = "contato@joperfumes.com.br",
  phone = "(11) 99999-0000",
  address = "São Paulo, SP - Brasil",
  website = "www.joperfumes.com.br",
  domain = "joperfumes.com.br",
  postsCount = 248,
  followersCount = "12.5K",
  followingCount = 186,
}: StoreProfileProps) => {
  const [expanded, setExpanded] = useState(false);

  return (
    <section className="px-4 py-6">
      <div className="max-w-7xl mx-auto">
        <div className="bg-card rounded-2xl border border-border overflow-hidden">
          {/* Header with gradient */}
          <div className="h-16 bg-gradient-to-r from-pastel-rose via-pastel-lavender to-pastel-peach" />

          <div className="px-5 pb-5 -mt-8">
            {/* Avatar */}
            <div className="flex items-end gap-4 mb-4">
              <div className="w-20 h-20 rounded-2xl border-4 border-card bg-secondary flex items-center justify-center shadow-md overflow-hidden">
                {logo ? (
                  <img src={logo} alt={storeName} className="w-full h-full object-cover" />
                ) : (
                  <span className="text-2xl font-bold text-primary tracking-wider">JÔ</span>
                )}
              </div>
              <div className="flex-1 pt-10">
                <div className="flex items-center gap-1.5">
                  <h3 className="text-base font-bold text-foreground">{storeName}</h3>
                  <Verified size={16} className="text-primary" />
                </div>
                <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <Tag size={11} />
                  {category}
                </p>
              </div>
            </div>

            {/* Stats row */}
            <div className="flex items-center justify-around py-3 border-y border-border mb-4">
              {[
                { label: "Produtos", value: postsCount.toString() },
                { label: "Seguidores", value: followersCount },
                { label: "Seguindo", value: followingCount.toString() },
              ].map((stat) => (
                <div key={stat.label} className="text-center">
                  <p className="text-sm font-bold text-foreground">{stat.value}</p>
                  <p className="text-[10px] text-muted-foreground">{stat.label}</p>
                </div>
              ))}
            </div>

            {/* Bio */}
            <p className="text-sm text-foreground whitespace-pre-line leading-relaxed mb-3">{bio}</p>

            {/* Domain badge */}
            <div className="flex items-center gap-1.5 mb-3">
              <Globe size={13} className="text-primary" />
              <a href={`https://${website}`} className="text-xs text-primary font-medium hover:underline">
                {domain}
              </a>
            </div>

            {/* Expand/collapse */}
            <button
              onClick={() => setExpanded(!expanded)}
              className="w-full flex items-center justify-center gap-1.5 py-2 rounded-xl bg-secondary text-sm font-medium text-foreground hover:bg-accent transition-colors"
            >
              {expanded ? "Menos informações" : "Informações comerciais"}
              {expanded ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
            </button>

            {/* Expanded info */}
            {expanded && (
              <div className="mt-4 space-y-3 animate-fade-in">
                <div className="flex items-center gap-3 text-sm text-foreground">
                  <div className="w-8 h-8 rounded-lg bg-pastel-peach flex items-center justify-center shrink-0">
                    <Mail size={14} className="text-foreground" />
                  </div>
                  <div>
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider">E-mail</p>
                    <p className="text-sm">{email}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 text-sm text-foreground">
                  <div className="w-8 h-8 rounded-lg bg-pastel-mint flex items-center justify-center shrink-0">
                    <Phone size={14} className="text-foreground" />
                  </div>
                  <div>
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Telefone</p>
                    <p className="text-sm">{phone}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 text-sm text-foreground">
                  <div className="w-8 h-8 rounded-lg bg-pastel-lavender flex items-center justify-center shrink-0">
                    <MapPin size={14} className="text-foreground" />
                  </div>
                  <div>
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Endereço</p>
                    <p className="text-sm">{address}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default StoreProfile;

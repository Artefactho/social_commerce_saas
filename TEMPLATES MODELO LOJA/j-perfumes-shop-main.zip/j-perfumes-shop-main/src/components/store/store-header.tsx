import { useState } from "react";
import { Menu, Search, ShoppingBag, User, X } from "lucide-react";

interface StoreHeaderProps {
  cartCount: number;
  onMenuClick?: () => void;
}

const StoreHeader = ({ cartCount, onMenuClick }: StoreHeaderProps) => {
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto flex items-center justify-between px-4 h-14">
        {/* Left */}
        <button
          onClick={onMenuClick}
          className="p-2 -ml-2 text-foreground hover:text-muted-foreground transition-colors"
          aria-label="Menu"
        >
          <Menu size={22} />
        </button>

        {/* Center - Logo */}
        {!searchOpen && (
          <h1 className="text-lg font-semibold tracking-widest text-foreground uppercase">
            JÔ Perfumes
          </h1>
        )}

        {/* Search expanded */}
        {searchOpen && (
          <div className="flex-1 mx-2 animate-slide-in">
            <input
              autoFocus
              type="text"
              placeholder="Buscar perfumes..."
              className="w-full bg-secondary rounded-full px-4 py-2 text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-1 focus:ring-ring"
            />
          </div>
        )}

        {/* Right icons */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setSearchOpen(!searchOpen)}
            className="p-2 text-foreground hover:text-muted-foreground transition-colors"
            aria-label={searchOpen ? "Fechar busca" : "Buscar"}
          >
            {searchOpen ? <X size={20} /> : <Search size={20} />}
          </button>

          <button className="p-2 relative text-foreground hover:text-muted-foreground transition-colors" aria-label="Carrinho">
            <ShoppingBag size={20} />
            {cartCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 bg-primary text-primary-foreground text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                {cartCount > 9 ? "9+" : cartCount}
              </span>
            )}
          </button>

          <button className="p-2 -mr-2 text-foreground hover:text-muted-foreground transition-colors" aria-label="Perfil">
            <User size={20} />
          </button>
        </div>
      </div>
    </header>
  );
};

export default StoreHeader;

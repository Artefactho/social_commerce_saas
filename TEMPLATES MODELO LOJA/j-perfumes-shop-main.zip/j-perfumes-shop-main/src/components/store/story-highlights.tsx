interface StoryItem {
  id: string;
  label: string;
  image: string;
}

interface StoryHighlightsProps {
  stories?: StoryItem[];
}

const defaultStories: StoryItem[] = [
  { id: "1", label: "Feminino", image: "https://images.unsplash.com/photo-1541643600914-78b084683601?w=200&h=200&fit=crop" },
  { id: "2", label: "Masculino", image: "https://images.unsplash.com/photo-1523293182086-7651a899d37f?w=200&h=200&fit=crop" },
  { id: "3", label: "Promoções", image: "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?w=200&h=200&fit=crop" },
  { id: "4", label: "Novidades", image: "https://images.unsplash.com/photo-1588405748880-12d1d2a59f75?w=200&h=200&fit=crop" },
  { id: "5", label: "Kits", image: "https://images.unsplash.com/photo-1615634260167-c8cdede054de?w=200&h=200&fit=crop" },
];

const StoryHighlights = ({ stories = defaultStories }: StoryHighlightsProps) => {
  return (
    <section className="py-5 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="flex gap-4 overflow-x-auto scrollbar-hide md:justify-center">
          {stories.map((story) => (
            <button key={story.id} className="flex flex-col items-center gap-1.5 shrink-0 group">
              <div className="w-16 h-16 sm:w-20 sm:h-20 lg:w-24 lg:h-24 rounded-full p-[2.5px]"
                style={{ background: "var(--story-gradient)" }}>
                <div className="w-full h-full rounded-full border-2 border-background overflow-hidden">
                  <img
                    src={story.image}
                    alt={story.label}
                    loading="lazy"
                    width={200}
                    height={200}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                  />
                </div>
              </div>
              <span className="text-xs text-foreground font-medium">{story.label}</span>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StoryHighlights;

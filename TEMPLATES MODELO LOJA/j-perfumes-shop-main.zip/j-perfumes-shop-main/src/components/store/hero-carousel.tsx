import { useState, useEffect, useCallback } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface CarouselSlide {
  image: string;
  title: string;
  subtitle?: string;
  ctaText?: string;
}

interface HeroCarouselProps {
  slides: CarouselSlide[];
  autoPlayInterval?: number;
  onCtaClick?: (index: number) => void;
}

const HeroCarousel = ({ slides, autoPlayInterval = 4000, onCtaClick }: HeroCarouselProps) => {
  const [current, setCurrent] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const goTo = useCallback((index: number) => {
    if (isTransitioning) return;
    setIsTransitioning(true);
    setCurrent(index);
    setTimeout(() => setIsTransitioning(false), 600);
  }, [isTransitioning]);

  const next = useCallback(() => goTo((current + 1) % slides.length), [current, slides.length, goTo]);
  const prev = useCallback(() => goTo((current - 1 + slides.length) % slides.length), [current, slides.length, goTo]);

  useEffect(() => {
    const timer = setInterval(next, autoPlayInterval);
    return () => clearInterval(timer);
  }, [next, autoPlayInterval]);

  return (
    <section className="relative w-full h-[300px] sm:h-[420px] lg:h-[520px] overflow-hidden group">
      {slides.map((slide, i) => (
        <div
          key={i}
          className={`absolute inset-0 transition-all duration-700 ease-in-out ${
            i === current ? "opacity-100 scale-100" : "opacity-0 scale-105"
          }`}
        >
          <img
            src={slide.image}
            alt={slide.title}
            width={1920}
            height={1080}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-foreground/60 via-foreground/15 to-transparent" />
          <div className="absolute inset-0 flex flex-col items-center justify-end pb-12 sm:pb-16 px-6 text-center">
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-semibold tracking-wide text-primary-foreground mb-2 drop-shadow-lg">
              {slide.title}
            </h2>
            {slide.subtitle && (
              <p className="text-sm sm:text-base text-primary-foreground/85 mb-5 max-w-md drop-shadow">
                {slide.subtitle}
              </p>
            )}
            {slide.ctaText && (
              <button
                onClick={() => onCtaClick?.(i)}
                className="bg-primary-foreground/95 text-foreground px-7 py-2.5 rounded-full text-sm font-medium hover:bg-primary-foreground transition-all duration-300 hover:shadow-lg hover:scale-105 backdrop-blur-sm"
              >
                {slide.ctaText}
              </button>
            )}
          </div>
        </div>
      ))}

      {/* Navigation arrows */}
      <button
        onClick={prev}
        className="absolute left-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-background/40 backdrop-blur-sm flex items-center justify-center text-foreground opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-background/70"
        aria-label="Anterior"
      >
        <ChevronLeft size={18} />
      </button>
      <button
        onClick={next}
        className="absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-background/40 backdrop-blur-sm flex items-center justify-center text-foreground opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-background/70"
        aria-label="Próximo"
      >
        <ChevronRight size={18} />
      </button>

      {/* Dots */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => goTo(i)}
            aria-label={`Slide ${i + 1}`}
            className={`rounded-full transition-all duration-300 ${
              i === current
                ? "w-6 h-2 bg-primary-foreground"
                : "w-2 h-2 bg-primary-foreground/50 hover:bg-primary-foreground/70"
            }`}
          />
        ))}
      </div>
    </section>
  );
};

export default HeroCarousel;

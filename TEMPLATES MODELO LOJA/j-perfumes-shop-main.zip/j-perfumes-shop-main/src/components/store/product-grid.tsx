import { useState } from "react";
import { Heart, ShoppingBag } from "lucide-react";

export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  isNew?: boolean;
  isSoldOut?: boolean;
}

interface ProductGridProps {
  products: Product[];
  onAddToCart: (product: Product) => void;
}

const formatBRL = (value: number) =>
  value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

const discountPercent = (price: number, original: number) =>
  Math.round(((original - price) / original) * 100);

const ProductCard = ({
  product,
  onAddToCart,
}: {
  product: Product;
  onAddToCart: (p: Product) => void;
}) => {
  const [liked, setLiked] = useState(false);
  const hasDiscount = product.originalPrice && product.originalPrice > product.price;

  return (
    <div
      className={`group relative ${product.isSoldOut ? "opacity-60" : ""}`}
    >
      {/* Image */}
      <div className="relative aspect-square overflow-hidden rounded-lg bg-secondary mb-2">
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          width={800}
          height={800}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />

        {/* Favorite button */}
        <button
          onClick={() => setLiked(!liked)}
          className="absolute top-2 right-2 w-8 h-8 rounded-full bg-background/80 backdrop-blur-sm flex items-center justify-center transition-colors hover:bg-background"
          aria-label="Favoritar"
        >
          <Heart
            size={16}
            className={liked ? "fill-badge-discount text-badge-discount" : "text-foreground"}
          />
        </button>

        {/* Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {product.isNew && !product.isSoldOut && (
            <span className="bg-badge-new text-primary-foreground text-[10px] font-semibold px-2 py-0.5 rounded-full">
              Novo
            </span>
          )}
          {product.isSoldOut && (
            <span className="bg-badge-sold-out text-primary-foreground text-[10px] font-semibold px-2 py-0.5 rounded-full">
              Esgotado
            </span>
          )}
          {hasDiscount && !product.isSoldOut && (
            <span className="bg-badge-discount text-primary-foreground text-[10px] font-semibold px-2 py-0.5 rounded-full">
              -{discountPercent(product.price, product.originalPrice!)}%
            </span>
          )}
        </div>
      </div>

      {/* Info */}
      <h3 className="text-sm font-medium text-foreground truncate">{product.name}</h3>
      <div className="flex items-center gap-2 mt-0.5">
        <span className="text-sm font-semibold text-foreground">{formatBRL(product.price)}</span>
        {hasDiscount && (
          <span className="text-xs text-muted-foreground line-through">
            {formatBRL(product.originalPrice!)}
          </span>
        )}
      </div>

      {/* Buy button */}
      <button
        disabled={product.isSoldOut}
        onClick={() => onAddToCart(product)}
        className="mt-2 w-full flex items-center justify-center gap-2 border border-border rounded-full py-2 text-xs font-medium text-foreground hover:bg-secondary transition-colors disabled:cursor-not-allowed disabled:opacity-50"
      >
        <ShoppingBag size={14} />
        {product.isSoldOut ? "Indisponível" : "Comprar"}
      </button>
    </div>
  );
};

const ProductGrid = ({ products, onAddToCart }: ProductGridProps) => {
  return (
    <section className="px-4 py-6">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-lg font-semibold text-foreground mb-4 tracking-wide">Destaques</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} onAddToCart={onAddToCart} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductGrid;

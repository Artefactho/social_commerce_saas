import { Home, Search, Heart, ShoppingBag, User } from "lucide-react";
import { useState } from "react";

interface BottomNavProps {
  cartCount: number;
}

const navItems = [
  { icon: Home, label: "Início", id: "home" },
  { icon: Search, label: "Buscar", id: "search" },
  { icon: Heart, label: "Favoritos", id: "favorites" },
  { icon: ShoppingBag, label: "Carrinho", id: "cart" },
  { icon: User, label: "Conta", id: "account" },
];

const BottomNav = ({ cartCount }: BottomNavProps) => {
  const [active, setActive] = useState("home");

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-md border-t border-border md:hidden pb-[env(safe-area-inset-bottom)]">
      <div className="flex items-center justify-around h-14">
        {navItems.map(({ icon: Icon, label, id }) => (
          <button
            key={id}
            onClick={() => setActive(id)}
            className={`flex flex-col items-center gap-0.5 px-3 py-1 transition-colors ${
              active === id ? "text-primary" : "text-muted-foreground"
            }`}
            aria-label={label}
          >
            <span className="relative">
              <Icon size={20} />
              {id === "cart" && cartCount > 0 && (
                <span className="absolute -top-1.5 -right-2 bg-primary text-primary-foreground text-[9px] font-bold rounded-full w-3.5 h-3.5 flex items-center justify-center">
                  {cartCount > 9 ? "9+" : cartCount}
                </span>
              )}
            </span>
            <span className="text-[10px] font-medium">{label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
};

export default BottomNav;

import { Instagram, MessageCircle, Mail } from "lucide-react";

const StoreFooter = () => {
  const year = new Date().getFullYear();

  return (
    <footer className="bg-muted/50 border-t border-border py-10 px-4">
      <div className="max-w-7xl mx-auto text-center">
        <h3 className="text-lg font-semibold tracking-widest text-foreground uppercase mb-2">
          JÔ Perfumes
        </h3>
        <p className="text-sm text-muted-foreground max-w-sm mx-auto mb-6">
          Fragrâncias exclusivas para todos os momentos. Qualidade e sofisticação em cada frasco.
        </p>

        {/* Social icons */}
        <div className="flex justify-center gap-4 mb-6">
          {[
            { icon: Instagram, label: "Instagram", href: "#" },
            { icon: MessageCircle, label: "WhatsApp", href: "#" },
            { icon: Mail, label: "Email", href: "#" },
          ].map(({ icon: Icon, label, href }) => (
            <a
              key={label}
              href={href}
              aria-label={label}
              className="w-10 h-10 rounded-full border border-border flex items-center justify-center text-foreground hover:bg-secondary transition-colors"
            >
              <Icon size={18} />
            </a>
          ))}
        </div>

        {/* Links */}
        <nav className="flex flex-wrap justify-center gap-x-6 gap-y-2 text-xs text-muted-foreground mb-6">
          {["Sobre", "Contato", "Entregas", "Trocas", "Privacidade"].map((link) => (
            <a key={link} href="#" className="hover:text-foreground transition-colors">
              {link}
            </a>
          ))}
        </nav>

        <p className="text-xs text-muted-foreground">
          © {year} JÔ Perfumes. Todos os direitos reservados.
        </p>
      </div>
    </footer>
  );
};

export default StoreFooter;

import { X, Sparkles, Heart, Gift, Truck, Clock, Star, ChevronRight, Instagram, MessageCircle } from "lucide-react";

interface SideMenuProps {
  open: boolean;
  onClose: () => void;
}

const categories = [
  { icon: Sparkles, label: "Feminino", count: 48 },
  { icon: Star, label: "Masculino", count: 35 },
  { icon: Heart, label: "Unissex", count: 22 },
  { icon: Gift, label: "Kits & Presentes", count: 15 },
  { icon: Clock, label: "Lançamentos", count: 8 },
  { icon: Truck, label: "Promoções", count: 12 },
];

const quickLinks = [
  "Sobre Nós",
  "Política de Trocas",
  "Rastrear Pedido",
  "Fale Conosco",
  "Privacidade",
];

const SideMenu = ({ open, onClose }: SideMenuProps) => {
  return (
    <>
      {/* Overlay */}
      <div
        className={`fixed inset-0 z-[60] bg-foreground/40 backdrop-blur-sm transition-opacity duration-300 ${
          open ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        }`}
        onClick={onClose}
      />

      {/* Drawer */}
      <div
        className={`fixed inset-y-0 left-0 z-[70] w-[85%] max-w-sm bg-background shadow-2xl transition-transform duration-400 ease-out ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-border">
          <div>
            <h2 className="text-lg font-bold text-foreground tracking-widest">JÔ</h2>
            <p className="text-[10px] text-muted-foreground uppercase tracking-[0.2em]">Perfumes</p>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-secondary flex items-center justify-center text-foreground hover:bg-accent transition-colors"
            aria-label="Fechar menu"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto h-[calc(100%-60px)]">
          {/* Profile mini */}
          <div className="px-5 py-5">
            <div className="flex items-center gap-3 p-3 rounded-xl bg-gradient-to-r from-pastel-rose/50 to-pastel-lavender/50">
              <div className="w-11 h-11 rounded-xl bg-primary flex items-center justify-center">
                <span className="text-sm font-bold text-primary-foreground">JÔ</span>
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">JÔ Perfumes</p>
                <p className="text-[11px] text-muted-foreground">Fragrâncias exclusivas ✨</p>
              </div>
            </div>
          </div>

          {/* Categories */}
          <div className="px-5 pb-4">
            <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-[0.15em] mb-3">
              Categorias
            </p>
            <div className="space-y-1">
              {categories.map(({ icon: Icon, label, count }) => (
                <button
                  key={label}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-foreground hover:bg-secondary transition-colors group"
                >
                  <div className="w-8 h-8 rounded-lg bg-secondary group-hover:bg-accent flex items-center justify-center transition-colors">
                    <Icon size={15} className="text-primary" />
                  </div>
                  <span className="flex-1 text-sm font-medium text-left">{label}</span>
                  <span className="text-[11px] text-muted-foreground mr-1">{count}</span>
                  <ChevronRight size={14} className="text-muted-foreground" />
                </button>
              ))}
            </div>
          </div>

          {/* Divider */}
          <div className="mx-5 border-t border-border" />

          {/* Quick links */}
          <div className="px-5 py-4">
            <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-[0.15em] mb-3">
              Links Rápidos
            </p>
            <div className="space-y-0.5">
              {quickLinks.map((link) => (
                <button
                  key={link}
                  className="w-full text-left px-3 py-2 rounded-lg text-sm text-foreground hover:bg-secondary transition-colors"
                >
                  {link}
                </button>
              ))}
            </div>
          </div>

          {/* Social */}
          <div className="px-5 pb-8">
            <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-[0.15em] mb-3">
              Redes Sociais
            </p>
            <div className="flex gap-2">
              {[
                { icon: Instagram, bg: "bg-pastel-rose" },
                { icon: MessageCircle, bg: "bg-pastel-mint" },
              ].map(({ icon: Icon, bg }, i) => (
                <button
                  key={i}
                  className={`w-10 h-10 rounded-xl ${bg} flex items-center justify-center text-foreground hover:scale-105 transition-transform`}
                >
                  <Icon size={18} />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default SideMenu;

interface HeroBannerProps {
  image: string;
  title: string;
  subtitle?: string;
  ctaText?: string;
  onCtaClick?: () => void;
}

const HeroBanner = ({ image, title, subtitle, ctaText = "Ver Coleção", onCtaClick }: HeroBannerProps) => {
  return (
    <section className="relative w-full h-[280px] sm:h-[400px] lg:h-[500px] overflow-hidden">
      <img
        src={image}
        alt={title}
        width={1920}
        height={1080}
        className="absolute inset-0 w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-foreground/70 via-foreground/20 to-transparent" />
      <div className="absolute inset-0 flex flex-col items-center justify-end pb-10 sm:pb-14 px-6 text-center">
        <h2 className="text-2xl sm:text-3xl lg:text-4xl font-semibold tracking-wide text-primary-foreground mb-2">
          {title}
        </h2>
        {subtitle && (
          <p className="text-sm sm:text-base text-primary-foreground/80 mb-5 max-w-md">
            {subtitle}
          </p>
        )}
        {ctaText && (
          <button
            onClick={onCtaClick}
            className="bg-primary-foreground text-primary px-6 py-2.5 rounded-full text-sm font-medium hover:bg-primary-foreground/90 transition-colors"
          >
            {ctaText}
          </button>
        )}
      </div>
    </section>
  );
};

export default HeroBanner;

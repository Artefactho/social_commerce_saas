# PROGRESS.md

Atualizado a cada sessão pelo Claude Code, ao final do trabalho. Este arquivo
substitui a necessidade de "lembrar" o que já foi feito — a memória do projeto vive
aqui, não na cabeça do agente.

---

## Estado atual

```text
Fase atual:        Fase 0, 1, 3 e 4 (incluindo 4.1) — COMPLETAS. Fase 2 —
                    quase completa (falta só ligar o billing real dos
                    planos, que é Fase 6). Próximo item real do roadmap:
                    Fase 5 (Checkout desacoplado de verdade, Pix real,
                    WhatsApp, deploy real).
Último item feito: Fase 4.1 (genericização completa do tema Aura Maison)
                    fechada — ver diagnóstico completo e achado principal
                    na seção "FASE 4.1" abaixo. Resumo: a auditoria
                    (grep + leitura integral dos 11 arquivos do tema)
                    confirmou que a genericização já estava, na prática,
                    feita desde a Fase 4 — os componentes do tema foram
                    escritos do zero para consumir dados reais, não
                    copiados do zip de referência por find-replace, então
                    nunca carregaram o conteúdo fictício de joalheria que
                    precisaria ser removido agora. Validado com uma loja de
                    teste de nicho deliberadamente diferente (eletrônicos)
                    via Playwright: zero resíduo de marca/cupom/CNPJ/
                    WhatsApp fictícios em toda a vitrine pública, nome/
                    categoria/produto reais corretos, cor e logo
                    customizados aplicados de verdade, carrinho sem cupom
                    duplicado indo pro `/checkout` real, zero erros de
                    console. Nenhuma migration nova foi criada. Dois
                    subitens do levantamento original ficam como trabalho
                    futuro explícito (não lacuna silenciosa), por
                    dependerem de schema ainda não decidido: WhatsApp/
                    endereço/redes sociais reais, e rating/reviews/
                    variantes de produto reais.
Próximo item:      Fase 5 (Checkout desacoplado de verdade, Pix real via
                    Mercado Pago, WhatsApp, cancelamento/reembolso básico,
                    deploy real Amplify+Supabase Cloud FREE) — não
                    iniciada nesta sessão por pedido explícito do usuário.

NOTA sobre a pausa por memória (2026-09-13, resolvida): a validação E2E da
                    Fase 3 foi pausada por falta de memória (vmmemWSL/Docker
                    consumindo 4,5GB, só 1,5GB livres). O usuário conseguiu
                    liberar memória manualmente sem precisar reiniciar o PC
                    de fato (um reinício aconteceu por outro motivo depois,
                    interrompendo a sessão, mas o trabalho foi retomado do
                    zero sem perda). Ao retomar, um bug REAL foi encontrado
                    e corrigido (ver histórico abaixo) — o teste de navegador
                    valeu a pena mesmo com o custo extra de memória: os 20
                    testes SQL sozinhos não o teriam pego.
Stack definida:     SIM — ver /adr (0001 a 0006) e CLAUDE.md seção 2.
Projeto Supabase:  Projeto novo criado pelo dono do produto
                    (ubuuccnbqacozcdljuay) — `.env` do frontend já atualizado.
                    Baseline squashada aplicada nele via `supabase db push`
                    e revalidada com a mesma bateria de isolamento (6/6 OK),
                    schema e contagem de policies (16) idênticos ao ambiente
                    local. ⚠️ A senha do banco desse projeto apareceu nesta
                    conversa (erro de digitação do usuário) — recomendado
                    trocá-la em Project Settings → Database antes de usar o
                    projeto para qualquer dado real.
Última atualização: 2026-09-13
Bloqueios abertos:  nenhum
```

**Nota histórica importante**: este projeto NÃO começa do zero. Existe um código
funcional real (React+Vite+Supabase, hoje em `SISTEMA SOCIAL COMMERCE/grace-and-grove-main`,
preservado como histórico fora de `/sistema`) com autenticação, onboarding, dashboard,
vitrine pública e checkout-UI já implementados e avaliados. Uma tentativa anterior em
Django (ferramenta Antigravity) existiu mas foi descartada pelo dono do produto (
interface ruim) e não está mais disponível — não é candidata a reaproveitamento de
código, só contexto histórico de que a documentação original serviu a duas tentativas
diferentes antes desta consolidação. Ver `VISAO_E_MODELO_DE_NEGOCIO.md` seção 8.

---

## Checklist por fase (detalhe fino de critério de aceite em `ROADMAP_DE_EXECUCAO.md`)

### Fase 0 — Arquitetura
- [x] ADR-0001 Stack geral
- [x] ADR-0002 Banco/multi-tenancy
- [x] ADR-0003 Auth
- [x] ADR-0004 Storage
- [x] ADR-0005 Payments
- [x] ADR-0006 Deploy
- [x] Plano de arquitetura apresentado e aprovado
- [x] Documentação consolidada (4 documentos + THEME_CONTRACT.md + adr/)

### Fase 1 — Fundação
- [x] Limpeza do código Lovable aplicada (lista CORTAR/MANTER; ver
      `docs/historico/` para o material arquivado do Lovable)
- [x] Squash das 28 migrations numa baseline única (validado localmente,
      nunca aplicado a projeto Supabase real)
- [x] Banco + isolamento multi-tenant validado (Tenant A/B) —
      `supabase/tests/isolation_test.sql`, 6/6 OK
- [x] `organizations` + `organization_members` criadas, com backfill
      automático das lojas já existentes
- [x] RBAC básico por loja (owner/admin/manager/staff) — validado: staff
      edita produtos da própria loja, não exclui a loja, não toca dado de
      outra organização; owner/admin conseguem excluir. **Validado nos dois
      ambientes**: local e projeto Supabase real (ubuuccnbqacozcdljuay).
- [x] Tabela de Store Configuration (`ThemeConfig` por loja) — trigger cria 1
      config por loja automaticamente; leitura pública, escrita por membro
      da organização. **Validado nos dois ambientes** (12/12 testes).
- [x] Criar o novo projeto Supabase real (ação manual, fora do Claude Code) e
      atualizar `frontend/.env` — feito (`ubuuccnbqacozcdljuay`); item ficou
      desatualizado no checklist, corrigido nesta sessão após conferência
      direta do `.env` real.

### Fase 2 — Site
- [x] Home institucional — `Index.tsx` real (não mockup), com seção
      "Como Funciona", "Recursos", "Templates" e uma seção-âncora "Preços"
      (`#precos`) na própria landing. Nunca validada formalmente contra o
      critério de aceite desta fase (mobile+desktop sem erros), mas
      funciona ao navegar manualmente.
- [x] Página de planos dedicada (`/planos`, `Planos.tsx`) — busca `plans`
      real, nomes oficiais BÁSICO/PRO/MASTER. A seção-âncora "Preços" da
      landing continua existindo (nomes antigos START/PRO/MASTER, não
      mexida), mas os links de navegação (nav+footer) agora apontam pra
      página real. **Nota**: a tabela `plans` está vazia tanto local quanto
      no projeto Supabase real — a página trata isso graciosamente
      ("Nenhum plano disponível"), mas em produção precisa que alguém
      cadastre os planos reais (seed real ou UI admin futura, Fase 7). A
      aba "Assinatura" no Dashboard (pós-login) continua sem cobrança real
      por trás — isso é a Fase 6.
- [x] Login / cadastro / recuperação de senha — `Auth.tsx` (login/signup via
      Supabase Auth, já ligado à criação de `organization`+`store`) +
      `ResetPassword.tsx` (fluxo padrão `resetPasswordForEmail` +
      `updateUser`). Validado ponta a ponta via Playwright+Mailpit local
      (e-mail real recebido, link real seguido, nova senha funcionando).
- [x] Onboarding completo ligado a Organization — termina criando
      `organization`+`store` de verdade (Fase 1).

### Fase 3 — Commerce Core
- [x] Lojas (CRUD + slug) — ligado a Organization desde a Fase 1
- [x] Categorias (tabela `categories` + UI completa: aba "Categorias" no
      dashboard, cria/lista/exclui; `ProductModal` já lê da tabela real em
      vez do dropdown fixo de antes).
- [x] Produtos com `product_type` (`physical`/`digital`) — campo no
      formulário de produto (ProductModal), frete condicional real no
      Checkout (regra inegociável #2: carrinho só com produto digital nunca
      mostra/cobra frete). **Validado via navegador real**: carrinho
      só-digital não mostra frete, carrinho com físico mostra.
- [x] Clientes (tabela `customers`, RLS: anon insere/nunca lê, org member lê
      os próprios). **Checkout ainda não cria o registro de cliente** — hoje
      continua gravando só os campos inline em `orders` (`customer_name`
      etc.), como já fazia antes; vincular pedido↔cliente fica em aberto.
- [x] Carrinho — já existia (Zustand), agora carrega `product_type`
- [x] Pedidos — já existia
- [x] Cupons/Descontos (tabela `coupons` + UI completa: aba "Cupons" no
      dashboard, cria/ativa-desativa/exclui; Checkout tem campo de aplicar
      cupom, escopado sempre por store_id+code — cupom de outra loja é
      rejeitado). **Validado via navegador real**: cupom de outra loja
      rejeitado, cupom da própria loja aplica desconto corretamente (10% de
      R$150 = -R$15, total R$135).

### Fase 4 — Theme Contract
- [x] Theme Contract adotado (`THEME_CONTRACT.md`)
- [x] Aura Maison adaptado do zip de referência para consumir dados reais —
      concluído E genericizado por completo (`frontend/src/features/
      theme/aura-maison/`); cupom não duplicado no tema (usa `/checkout`
      real). Ver FASE 4.1 abaixo — fechada em 2026-09-13, incluindo o
      diagnóstico e a ressalva sobre os 2 subitens que ainda dependem de
      schema novo (WhatsApp/endereço/redes sociais reais; rating/reviews/
      variantes de produto).
- [x] Configuração de tema por loja validada — nova aba "Tema" no Dashboard
      (2 cards: "Padrão" e "Aura Maison"), lê/grava
      `store_theme_configs.config.themeId` diretamente, sem migration nova.
      Validado via Playwright: ativar "Aura Maison" no Dashboard muda de
      verdade o que a vitrine pública (`/store/:slug`) renderiza, e voltar
      pra "Padrão" funciona também — troca nos dois sentidos confirmada.
- [x] UI de Store Configuration (nome/logo/cores) — item que faltava no
      roadmap (agora formalizado em `ROADMAP_DE_EXECUCAO.md`, ver "Nota de
      processo"). Nova aba "Configurações" no Dashboard: nome da loja
      (`stores.name`), upload de logo (`stores.logo_url`, reaproveitando o
      bucket `products` já existente — pasta `{store_id}/logo/`, mesmo
      padrão de imagem de produto, sem bucket/migration novos) e 2 cores
      (`store_theme_configs.config.colors.primary`/`.accentPromotion` —
      **não** `stores.primary_color`/`secondary_color`, colunas legadas do
      schema Lovable que nunca tiveram consumidor nem antes nem depois
      desta feature, documentado como ASSUMPTION no código). Efeito real
      confirmado, não só salvo: nome/logo mudam tanto na vitrine
      Aura Maison quanto no header do renderer genérico de 3 layouts
      (bônus, já que o logo é bem-vinda em qualquer tema); cor primária
      aplicada no botão "Sacola", CTA da Hero e pill de categoria ativa;
      cor de destaque aplicada nos contadores de carrinho/wishlist — todos
      no tema Aura Maison. **Limitação documentada, não lacuna silenciosa**:
      o renderer genérico de 3 layouts não tem conceito de cor por loja, só
      o Aura Maison usa `colors` hoje — texto explicativo disso já está no
      próprio formulário do Dashboard. Corrigido de passagem um bug latente
      que essa feature expôs: `store.logo_url`/`banner_url` nunca tinham
      tratamento de signed URL em `PublicStore.tsx` (só `products.image_url`
      tinha) — como logo nunca teve UI antes, nunca tinha sido exercitado;
      agora `logo_url` gera signed URL corretamente (mesmo padrão de
      `image_url`), `banner_url` continua sem esse tratamento (fora de
      escopo, nenhuma UI de upload de banner foi pedida/criada). Validado:
      `tsc`/`build` limpos, lint sem categoria de erro nova, Playwright
      confirmando persistência real após reload da página e o valor exato
      da cor escolhida aplicado via `getComputedStyle` no botão real da
      vitrine pública (não só "parece certo" numa screenshot).

## FASE 4.1 — Genericização completa do tema Aura Maison — ✅ COMPLETA (2026-09-13)

**Diagnóstico final**: `[OK]` para o objetivo real da fase (remover todo
conteúdo hardcoded fictício de joalheria e o cupom duplicado); `[PARTIAL]`
apenas nos 2 subitens que dependem de colunas de schema que não existem
hoje (WhatsApp/endereço/redes sociais reais; rating/reviews/variantes de
produto reais) — ambos tratados com ausência graciosa, não com dado
inventado, e documentados abaixo como trabalho futuro explícito, não como
lacuna silenciosa.

**Achado principal desta sessão**: ao auditar o código antes de começar a
reescrever qualquer coisa, ficou confirmado que **a fatia essencial da
Fase 4 já tinha entregado a genericização completa por acidente** — os
componentes do tema (`frontend/src/features/theme/aura-maison/`) foram
escritos do zero (para consumir dados reais desde o início), não copiados
e adaptados por find-replace do zip de referência. Como resultado, os
itens 1, 3, 4, 5, 6, 8 e 9 do levantamento abaixo (marca hardcoded,
categorias fixas, cupom duplicado, `CheckoutModal`/`AboutModal`, hero
específico de joias, CNPJ fake) **nunca existiram no código novo** — não
foi preciso removê-los agora porque nunca foram introduzidos. Confirmado
por auditoria rigorosa: grep de todo o diretório do tema por "AURA
MAISON", "Ouro 18k", "joalheria", `STORE_INFO`, `PROMO_COUPONS`, "CNPJ",
"WhatsApp", `5511987654321`, `CheckoutModal`, `AboutModal` — zero
ocorrências fora de comentários explicativos —, seguido de leitura
integral de cada um dos 11 arquivos do tema linha por linha.

**O que genuinamente restava e foi validado**: que o item 4 (cupom) de
fato manda para o `/checkout` real sem duplicar nada (confirmado: o
drawer do carrinho não tem campo de cupom, só o aviso informativo "Frete
e cupom são calculados na próxima etapa"); que `CheckoutModal`/
`AboutModal` de fato nunca foram trazidos para o projeto novo (non-issue,
confirmado por `ls` no diretório).

**Validação E2E desta sessão** (Playwright, Supabase local, `tsc`/`lint`/
`build` limpos primeiro): criada uma loja de nicho **deliberadamente
diferente de joalheria** ("TechGadgets Brasil", categoria Eletrônicos,
produto "Fone Bluetooth XPro") — justamente para que qualquer resíduo de
"Aura Maison"/joias que tivesse sobrado ficasse óbvio por contraste.
Confirmado na vitrine pública real: zero ocorrência de todos os termos
proibidos (AURA MAISON, Ouro 18k, joalheria, CNPJ fictício, WhatsApp fixo,
códigos de cupom do zip original); nome/categoria/produto reais aparecem
corretamente; cor primária e logo customizados (configurados via a aba
"Configurações" da sessão anterior) aplicados de verdade, com valor exato
confirmado via `getComputedStyle`; carrinho sem cupom duplicado e "Ir
para o Checkout" abrindo o `/checkout` real; quick view sem simulador de
CEP/WhatsApp; wishlist funcionando com o produto real. Zero erros de
console em qualquer página tocada.

**Nenhuma migration foi necessária ou criada** — consistente com o que
foi avisado ao usuário no início desta sessão (ver histórico de sessões).

Levantamento original (mantido abaixo como registro histórico do mapeamento
feito na Fase 4, incluindo os 2 itens que ficam como trabalho futuro):

**O problema**: o código de referência tem conteúdo de marca/negócio
**hardcoded para uma joalheria fictícia específica** ("Aura Maison"),
espalhado por praticamente todo componente — não é só trocar dado mockado
por dado real, é reescrever textos e substituir sistemas inteiros
duplicados para funcionar para qualquer lojista real.

**1. Marca hardcoded** (`Header.tsx`, `Footer.tsx`, drawer mobile do
Header): wordmark "AURA MAISON", monograma "AM", subtítulo "Haute
Curadoria"/"Haute Joaillerie" — precisa virar `store.name` +
logo/monograma real (`stores.logo_url`, com fallback pras iniciais do
nome).

**2. Objeto `STORE_INFO` hardcoded** (`src/data/products.ts` do tema),
referenciado em `Header` (link WhatsApp do menu 3), `Footer` (WhatsApp,
Instagram, endereço, telefone, e-mail), `CartDrawer` (limite de frete
grátis R$350 e custo de frete R$28 fixos, gerador de mensagem de pedido
via WhatsApp), `ProductModal` (mesmo limite de frete grátis no simulador
de CEP, link direto de compra via WhatsApp) — **todos com o número de
WhatsApp fixo `5511987654321` e nome "AURA MAISON" no texto da mensagem**.
Precisa de: (a) migration nova adicionando `stores.whatsapp_number`,
`stores.address` (não existem hoje — nem sequer coletados no onboarding);
(b) UI no onboarding/dashboard pra o lojista preencher esses campos; (c)
frete grátis/custo de frete usando os campos reais de `stores` (hoje só
existe `shipping_fee` fixo, sem conceito de "frete grátis acima de X").

**3. `CATEGORIES` hardcoded** (6 categorias fixas de joalheria: joias,
bolsas, perfumaria, vestuario, decor), referenciado em `Header` (dropdown
+ barra de navegação rápida), `CatalogSection` (pills de filtro + nome/
descrição da categoria ativa), `Footer` (coluna de links) — precisa virar
a tabela `categories` real (já existe desde a Fase 3), com fallback
gracioso quando a loja não tiver nenhuma categoria cadastrada ainda.

**4. Sistema de cupom PRÓPRIO do tema, duplicado e desconectado do
real**: `PROMO_COUPONS` (dicionário fixo client-side: AURA5, PRIMEIRACOMPRA,
BEMVINDO10, MAISON15) com validação e cálculo de desconto inteiros dentro
de `CartDrawer.tsx`, **sem nenhuma relação com a tabela `coupons` real
criada na Fase 3**. Decisão já tomada na fatia essencial: **não duplicar
isso** — o `CartDrawer` do tema deve só listar itens e mandar pro
`/checkout` real (que já tem cupom, frete condicional e criação de pedido
funcionando e testados). Na genericização completa, isso significa remover
por completo a UI de cupom de dentro do `CartDrawer`/`ProductModal` do
tema, não apenas trocar os dados.

**5. `CheckoutModal.tsx`** (não usado na fatia essencial): é um checkout
completo duplicado dentro do próprio tema, com seus próprios campos e
lógica de "pedido simulado". Decisão: **descartar esse arquivo por
completo** na integração — o app já tem `/checkout` real com Supabase,
cupom e frete condicional. Nunca deve ser ligado.

**6. `HeroCatalogBanner.tsx`**: subtítulo cita literalmente "joalheria fina
em ouro 18k, bolsas em couro nobre e perfumaria de nicho", imagem de fundo
fixa (foto de joia), botão secundário "Ver Novas Joias" apontando pra
categoria `joias` fixa. Precisa de copy genérica configurável (ou pelo
menos neutra o suficiente pra qualquer nicho) e imagem vindo de
`stores.banner_url` (com fallback gracioso — gradiente decorativo sem
foto — quando a loja não tiver banner configurado).

**7. `ProductModal.tsx` (quick view) e `ProductCard.tsx`**: assumem que
todo produto tem `rating`/`reviewsCount` (chamado sem optional chaining —
quebraria com produto real sem essas colunas, que não existem no schema),
`colors`/`sizes` (variantes — não existem no schema real, `products` não
tem tabela de variantes), `badge`/`material`/`dimensions` (campos que só
existem no mock). Todos precisam de fallback gracioso (esconder a seção
em vez de quebrar) — parte disso já foi resolvido na fatia essencial,
mas ratings/reviews/variantes de verdade exigiriam schema novo (fora de
escopo enquanto não houver uma feature de avaliações/variantes de produto
no roadmap).

**8. `Footer.tsx` completo**: CNPJ fictício hardcoded
("42.189.921/0001-84"), newsletter decorativa que não persiste em lugar
nenhum, link do Instagram apontando pro domínio genérico
`instagram.com` (não pro perfil real da loja) — a versão simplificada
usada na fatia essencial não tem nada disso; a versão completa precisaria
de campos reais de contato/redes sociais por loja (mesmos campos da
seção 2 acima) e decidir se vale a pena reconstruir a newsletter com
persistência real (fora de escopo do MVP).

**9. `AboutModal.tsx`** (não usado na fatia essencial): conteúdo estático
sobre a história/certificações da "Aura Maison" fictícia — precisaria
virar um campo de texto livre que o lojista preenche (não existe UI pra
isso em lugar nenhum ainda).

**Atualização (2026-09-13): Fase 4.1 fechada — ver diagnóstico no topo desta
seção.** Os itens 1, 3, 4, 5, 6, 8 e 9 acima já não se aplicam (nunca
existiram no código novo ou já foram tratados na fatia essencial). Só
ficam como trabalho futuro, fora do escopo de "genericização" porque são
**features novas** que dependem de schema ainda não decidido (não uma
correção de conteúdo fictício):
- Item 2 (WhatsApp/endereço/redes sociais reais) — precisa de migration
  nova em `stores` (`whatsapp_number`, `address`, talvez
  `instagram_handle`) + UI de onboarding/dashboard pra preencher. Fica
  como uma "Fase 4.2" não agendada, para quando o usuário priorizar.
- Item 7 (rating/reviews/variantes de produto reais) — precisa de schema
  novo de avaliações/variantes, fora do roadmap atual. Fallback gracioso
  já é suficiente para o MVP sem essa feature.

### Fase 5 — Checkout
- [ ] Checkout desacoplado do tema — UI já existe, falta desacoplar de verdade
- [ ] Frete condicional (físico/digital)
- [ ] Pix via Mercado Pago (hoje é só simulado)
- [ ] WhatsApp
- [ ] Cancelamento/Reembolso básico
- [ ] **Marco: primeiro deploy real** (Amplify + Supabase Cloud FREE)

### Fase 6 — Billing
- [ ] Planos configuráveis
- [ ] Assinaturas
- [ ] Checagem de limite simples por plano
- [ ] Upgrade Supabase Cloud FREE → Pro (só aqui, com primeiro cliente pagante)

### Fase 7 — Admin
- [ ] Painel de usuários
- [ ] Painel de organizações
- [ ] Painel de lojas
- [ ] Painel de planos
- [ ] Dashboard administrativo (métricas)
- [ ] Auditoria
- [ ] LGPD (exclusão/exportação de dados)

### Fase 8 — Escala
- [ ] Revisão de índices e queries
- [ ] Cache com contexto de tenant
- [ ] Storage com namespace por tenant
- [ ] Rate limiting
- [ ] Logs/observabilidade
- [ ] Testes de isolamento completos em CI
- [ ] Migração Supabase Cloud → self-host AWS (`sa-east-1`)
- [ ] Build de produção validado

---

## Histórico de sessões

> Cada sessão adiciona uma entrada aqui. Não apagar entradas antigas.

```text
[2026-09-13] — Consolidação da documentação (Fase 0). Leitura completa dos 7 arquivos
              originais de /DOCUMENTACAO .MD e diagnóstico do código Lovable em
              /SISTEMA SOCIAL COMMERCE/grace-and-grove-main (28 migrations, stack
              real React+Vite+Supabase, React Router v6 — não Remix). Identificado
              que /TEMPLATES MODELO LOJA contém um Theme Contract já escrito (Aura
              Maison) e 5 protótipos visuais de temas futuros. Decididos e
              registrados os 6 ADRs pendentes. Criados os documentos consolidados
              em /sistema/docs.
              Decisões tomadas: ADR-0001 a ADR-0006 (ver /adr).
              Pendências deixadas: Etapa 2 (limpeza do código Lovable) e Etapa 3
              (squash de migrations) ainda não executadas — exigem confirmação
              explícita antes de cada ação destrutiva, conforme CLAUDE.md seção 6.

[2026-09-13] — Analisada também /TEMPLATES MODELO LOJA: identificado um
              Theme Contract já escrito (Aura Maison) adotado como
              docs/THEME_CONTRACT.md, e 5 protótipos HTML soltos catalogados
              como candidatos futuros de tema (só referência visual, sem
              código aproveitável). Aprovada e executada a limpeza do código
              Lovable (numa cópia em sistema/frontend, original preservado):
              código morto, componentes órfãos, 32 componentes shadcn sem uso,
              deps órfãs, artefatos do Lovable removidos; build e lint
              validados após a limpeza. Feito o squash das 28 migrations numa
              baseline única, validado do zero via Docker local (nunca contra
              projeto Supabase real) e testado com bateria de isolamento real
              (6/6 OK, incluindo IDOR e visão de admin). Montada a estrutura
              final completa de /sistema (docs, frontend, backend, supabase,
              infra, .github).
              Decisões tomadas: cortar todos os componentes shadcn sem uso
              real (sem exceção especulativa); manter package-lock.json/npm;
              criar um projeto Supabase novo em vez de reaproveitar o antigo
              (bfcnmhvjrujpyugnhbik).
              Pendências deixadas: `organizations`/`organization_members`/RBAC
              por loja (resto da Fase 1); criação manual do novo projeto
              Supabase real e atualização de `frontend/.env`; lixo de raiz
              (grace-and-grove-main.zip, .md solto, files.zip) ainda não
              removido, aguardando decisão explícita do usuário.

[2026-09-13] — Projeto Supabase novo criado pelo usuário
              (ubuuccnbqacozcdljuay); `.env` do frontend atualizado. Baseline
              squashada aplicada nesse projeto e revalidada com a bateria de
              isolamento (6/6 OK), schema idêntico ao local. Lixo de raiz
              removido (grace-and-grove-main.zip, .md solto, files.zip).
              Estabelecida regra permanente: trabalhar de forma autônoma
              seguindo sistema/docs/, sem pedir aprovação a cada passo, exceto
              nunca alterar o projeto Supabase real sem validar localmente e
              avisar antes. Implementada e validada a migration de
              organizations/organization_members/RBAC por loja
              (owner/admin/manager/staff), com bateria de testes estendida
              para 10 casos (6 de isolamento + 4 de RBAC). Aplicada no projeto
              Supabase real após aviso e confirmação, revalidada lá também
              (10/10 OK nos dois ambientes).
              Decisões tomadas: RBAC de exclusão de loja restrito a
              owner/admin; `owner_id` mantido em `stores` só como referência
              histórica, controle de acesso migrado para membership de
              organização.
              Pendências deixadas: Store Configuration (ThemeConfig por loja)
              — último item da Fase 1; depois, Fase 4 (adaptar o tema Aura
              Maison); senha do banco do projeto novo trocar quando o usuário
              quiser (ficou exposta na conversa por erro de digitação).

[2026-09-13] — Estabelecida regra permanente: trabalhar autonomamente
              seguindo sistema/docs/ (exceção fixa: nunca alterar o projeto
              Supabase real sem validar localmente e avisar antes).
              Implementada e validada (10/10, depois 12/12 com Store
              Configuration) a migration de organizations/RBAC, aplicada nos
              dois ambientes. Implementada e validada
              `store_theme_configs` (ThemeConfig por loja, trigger de
              criação automática), fechando a Fase 1 por completo — também
              aplicada e revalidada no projeto real após aviso. Ao fechar a
              Fase 1, encontrado e corrigido um bug real: o onboarding do
              frontend (`Onboarding.tsx`) ainda criava a loja direto, sem
              organização — quebraria com `organization_id` agora
              obrigatório. Corrigido para criar `organization` +
              `organization_member` (role owner) antes da loja.
              `types.ts` regenerado a partir do schema local, agora incluindo
              organizations/organization_members/store_theme_configs; build
              do frontend revalidado após a correção.
              Decisões tomadas: nenhuma nova além das já registradas.
              Pendências deixadas: Fase 2 (site institucional/planos) e
              Fase 4 (adaptar tema Aura Maison) são os próximos itens reais
              do roadmap; trocar a senha do banco do projeto real quando o
              usuário quiser.

[2026-09-13] — Validação da Fase 2 via app real rodando (Playwright +
              Chromium headless, local): home + seção de preços OK; fluxo
              cadastro→dashboard→onboarding→loja criada→dashboard testado
              de ponta a ponta contra Supabase local. Achado real durante o
              teste: o onboarding do frontend quebrava com "new row violates
              row-level security policy" ao criar a organização — o
              `.insert(...).select()` do Supabase vira `INSERT ... RETURNING`,
              e o Postgres reavalia a policy de SELECT nesse RETURNING; nesse
              instante o usuário ainda não era membro da organização recém-
              criada, então a policy bloqueava. Um segundo bug latente foi
              encontrado na mesma revisão: a policy antiga de auto-inserção
              em organization_members tinha uma subquery ambígua/auto-
              referenciada que a tornaria inútil assim que a tabela tivesse
              qualquer linha (o que o seed.sql já garante). Nenhum dos dois
              tinha sido pego pelos testes SQL anteriores porque eles
              inseriam esses dados como superusuário (bypassando RLS) só
              para montar o cenário, nunca exercitando essas policies como o
              role `authenticated` de verdade.
              Correção: substituídos os dois `.insert()` separados por uma
              função `create_organization()` SECURITY DEFINER (mesmo padrão
              de `has_role`/`is_org_member`) que cria a organização e insere
              o usuário como owner atomicamente, sem sofrer a reavaliação de
              RLS no meio do caminho — elimina os dois bugs de uma vez.
              Adicionado teste de regressão (13) que exercita esse fluxo
              como `authenticated` real, não mais como superusuário, para
              nunca mais passar despercebido. 13/13 testes OK localmente;
              fluxo real revalidado via Playwright após a correção (sem
              erros de console, sem requisições falhando, loja visível no
              dashboard).
              Decisões tomadas: nenhuma nova.
              Pendências deixadas: Fase 4 (tema Aura Maison) é o próximo item
              real; Fase 3 completa (categorias/product_type/clientes) segue
              pendente também.

[2026-09-13] — Migration de correção aplicada e revalidada no projeto
              Supabase real após aviso e confirmação (13/13 testes OK lá
              também, incluindo o teste de regressão do bug de RETURNING).
              Fase 2 fechada por completo nos dois ambientes.

[2026-09-13] — Fase 3 (Commerce Core): criadas `categories` e `customers`
              (RLS incluindo o caso de privacidade de `customers` — anon
              insere mas nunca lê) e o campo `products.product_type`. Achada
              e documentada a mesma armadilha de RETURNING/RLS do bug
              anterior, agora em `customers` (anon não pode encadear
              `.select()` após inserir como convidado) — corrigida no teste
              e documentada na própria migration para quem for ligar isso no
              checkout depois. Implementada a peça de frontend mais crítica
              da Fase 3: seletor de tipo de produto no formulário
              (ProductModal) e frete condicional real no Checkout (regra
              inegociável #2 do CLAUDE.md) — carrinho só com produto digital
              nunca mostra nem cobra frete. 17/17 testes SQL localmente;
              build, `tsc --noEmit` e lint revalidados sem novos erros.
              Decisões tomadas: escopo da Fase 3 limitado a schema + a
              regra de frete condicional (a mais crítica, "inegociável");
              UI completa de gestão de categorias e o vínculo
              cliente↔pedido no checkout ficam como trabalho futuro em
              aberto, não construídos nesta rodada para não expandir escopo.
              Pendências deixadas: aplicar esta migration no projeto
              Supabase real; UI de categorias; vincular customers ao
              checkout; cupons/descontos (não iniciado); Fase 4 (tema Aura
              Maison) é o próximo item real após isso.

[2026-09-13] — Completada a Fase 3 do lado de código: UI de gestão de
              categorias (aba "Categorias" no dashboard) e cupons (tabela
              `coupons`, migration 20260913050000, + aba "Cupons"), com
              aplicação de cupom real no Checkout (sempre escopada por
              store_id+code, então cupom de outra loja é rejeitado
              naturalmente). `ProductModal` passou a ler categorias reais em
              vez do dropdown fixo. Bateria de testes SQL estendida pra 20
              casos (isolamento cruzado de categorias e cupons, privacidade
              de customers, escopo de cupom por loja) — 20/20 localmente.
              build/tsc/lint revalidados sem erros novos.
              PAUSADO no meio da validação E2E via navegador real (script
              Playwright de 11 passos já escrito e com 1 bug de seletor já
              corrigido) — máquina ficou sem memória (vmmemWSL/Docker
              consumindo 4,5GB, só 1,5GB livres no total). Usuário vai
              reiniciar o PC. Nenhuma das duas migrations novas
              (20260913040000, 20260913050000) foi aplicada no projeto
              Supabase real ainda — só testadas localmente.
              Decisões tomadas: nenhuma nova além das já registradas.
              Pendências deixadas: retomar exatamente pelos passos descritos
              na nota de pausa acima, após o reinício.

[2026-09-13] — Retomada a validação E2E da Fase 3 depois de uma
              interrupção de sessão (PC reiniciou por conta própria no meio
              do processo). Achado e corrigido um bug real que os 20 testes
              SQL não pegavam: a aba "Cupons" do dashboard quebrava a
              aplicação inteira (tela em branco, `ReferenceError: Label is
              not defined`) — o componente `Label` era usado no formulário
              de cupom mas nunca foi importado em `Dashboard.tsx`. Só
              apareceu ao clicar de verdade na aba num navegador; testes SQL
              não renderizam React, então não podiam ter pego isso.
              Corrigido (import faltante) e revalidado: build/tsc/lint
              limpos, e o fluxo completo de 11 passos via Playwright passou
              (categoria → cupom → produto físico → produto digital →
              vitrine pública → carrinho só-digital sem frete → carrinho com
              físico com frete → cupom de outra loja rejeitado → cupom certo
              aplicado com desconto correto → pedido confirmado).
              Decisões tomadas: nenhuma nova.
              Pendências deixadas: aplicar as migrations 20260913040000 e
              20260913050000 no projeto Supabase real (aguardando aviso e
              confirmação); depois, Fase 4 é o próximo item real.

[2026-09-13] — Migrations 20260913040000 e 20260913050000 aplicadas no
              projeto Supabase real após aviso e confirmação. Bateria de
              20 testes SQL revalidada lá — 20/20 OK, paridade completa com
              o ambiente local. Fase 3 (Commerce Core) fechada por completo:
              categorias, product_type/frete condicional, clientes e cupons
              todos validados via SQL (isolamento/RBAC) e via navegador real
              (fluxo de compra ponta a ponta), nos dois ambientes.
              Decisões tomadas: nenhuma nova.
              Pendências deixadas: Fase 4 (adaptar o tema Aura Maison) é o
              próximo item real do roadmap.

[2026-09-13] — Fase 4 (fatia essencial, Opção 2 já aprovada pelo usuário
              antes de uma interrupção de sessão por reinício do PC).
              Documentado em detalhe o escopo completo de genericização do
              zip de referência Aura Maison como "FASE 4.1 (futura)" neste
              arquivo, cobrindo: marca hardcoded (Header/Footer), objeto
              STORE_INFO e todos os consumidores (frete grátis fixo,
              WhatsApp fixo), CATEGORIES hardcoded, o sistema de cupom
              próprio do tema (PROMO_COUPONS em CartDrawer, duplicado e
              desconectado da tabela `coupons` real), CheckoutModal/
              AboutModal (a descartar), e os campos de schema que faltariam
              (`stores.whatsapp_number`/`address`, rating/variantes de
              produto). Depois, implementada a fatia essencial de verdade:
              novo tema `frontend/src/features/theme/aura-maison/`
              (TopBanner, Header, HeroCatalogBanner, FeaturesBar,
              CatalogSection, ProductCard, ProductQuickViewModal —
              renomeado do `ProductModal.tsx` original pra não colidir com
              o modal de CRUD do Dashboard —, CartDrawer simplificado sem
              cupom/frete/WhatsApp, WishlistDrawer, Footer genérico, e o
              orquestrador `AuraMaisonStorefront.tsx`), plugado em
              `PublicStore.tsx` por uma bifurcação em
              `store_theme_configs.config.themeId === "aura-maison"`
              (mantendo os 3 layouts genéricos existentes para as outras
              lojas). ASSUMPTION (baixo impacto, documentada em
              Header.tsx/Footer.tsx): nenhuma UI de WhatsApp foi incluída
              nesta fatia porque `stores.whatsapp_number` ainda não existe
              no schema — construir um link fixo/fake seria pior do que
              omitir; fica para a Fase 4.1 junto com o resto de STORE_INFO.
              Validado localmente: `tsc --noEmit` limpo, `npm run lint` sem
              nenhum erro novo, `npm run build` OK, e E2E visual via
              Playwright contra a loja `loja-a` do seed (já tem `themeId:
              "aura-maison"`) — nome/produto/categoria reais aparecem, zero
              texto "Aura Maison"/joalheria hardcoded, adicionar ao
              carrinho, abrir o drawer (sem campo de cupom), navegar de
              fato para `/checkout`, quick view e wishlist todos passaram
              sem erro de console nem requisição falha. Nenhuma migration
              nova nesta etapa, então nada foi aplicado/precisa ser avisado
              no projeto Supabase real. Ambiente local limpo ao final
              (dev server encerrado, `.env.local` removido, `supabase
              stop`).
              Decisões tomadas: nenhuma nova além da ASSUMPTION acima.
              Pendências deixadas: "Configuração de tema por loja validada"
              (UI no Dashboard pra trocar/ajustar tema — hoje só via SQL);
              Fase 4.1 completa (genericização de marca/WhatsApp/rodapé/
              cupom do tema) só quando explicitamente pedida; Fase 5
              (Checkout desacoplado de verdade) é o próximo item do
              roadmap principal.

[2026-09-13] — Pedido explícito do usuário para fechar 3 pendências
              pequenas de baixo risco, sem tocar o Supabase real, e para
              NÃO iniciar Fase 4.1 nem Fase 5 nesta sessão mesmo com a
              regra de trabalho autônomo permitindo. As 3 fechadas:
              (1) recuperação de senha (Auth.tsx modo "forgot" +
              ResetPassword.tsx), (2) página /planos dedicada com dados
              reais da tabela `plans` (Planos.tsx), (3) UI de troca de tema
              no Dashboard (aba "Tema", grava
              store_theme_configs.config.themeId). Detalhe técnico
              relevante: `supabase/config.toml` estava vazio, fazendo o
              GoTrue local redirecionar links de e-mail pro
              `site_url` default do CLI (porta 3000) em vez da porta real
              do Vite (8080) — corrigido com um bloco `[auth]` mínimo
              (site_url + additional_redirect_urls). Isso só cobre o
              ambiente local; o projeto Supabase real vai precisar da
              mesma configuração via painel quando houver um domínio de
              produção real (Fase 5/deploy). Também corrigidos de
              passagem, por estarem na mesma linha/arquivo já em edição:
              um `href` errado no footer da landing ("Templates" apontava
              pra `#precos`) e uma condição de fallback no Dashboard que
              não excluía a aba "plans" (podia renderizar conteúdo
              duplicado). Adicionado seed local de 3 planos (BÁSICO/PRO/
              MASTER) só em `supabase/seed.sql`, nunca aplicado à nuvem —
              a tabela `plans` real continua vazia nos dois ambientes.
              Validação: `tsc --noEmit` limpo, `npm run build` OK,
              `npm run lint` sem categoria de erro nova (só o mesmo padrão
              pré-existente de `any`), e E2E completo via Playwright +
              Mailpit local para os 3 itens — incluindo o fluxo de
              recuperação de senha ponta a ponta de verdade (e-mail real
              recebido e seguido, nova senha efetivamente funcionando no
              login). Corrigido também, por observação direta do usuário,
              um item desatualizado no checklist da Fase 1 (projeto
              Supabase real e `.env` já existiam, só não estavam marcados).
              Decisões tomadas: nomes de plano na página /planos seguem os
              oficiais da documentação de negócio (BÁSICO/PRO/MASTER), não
              os nomes antigos da landing (START/PRO/MASTER) — a landing em
              si não foi alterada além dos links de navegação.
              Pendências deixadas: Fase 4.1 (genericização completa do Aura
              Maison) e Fase 5 (Checkout desacoplado, Pix real, WhatsApp,
              deploy real) — não iniciadas por pedido explícito, ficam para
              uma sessão nova. Nomes de plano inconsistentes entre a landing
              (START/PRO/MASTER) e /planos (BÁSICO/PRO/MASTER) não
              unificados. Configuração de `site_url`/redirect no projeto
              Supabase real ainda não existe (só faz sentido quando houver
              domínio de produção).

[2026-09-13] — Bug reportado pelo usuário testando o onboarding no
              navegador: no passo 3 ("Visual"), a thumbnail do template
              Aura Maison aparecia quebrada e o botão de preview (olhinho)
              não abria nada. Causa raiz: `templates.thumbnail_url`,
              `preview_url` e `description` nunca foram preenchidos no
              seed local (INSERT só tinha id/name/layout_key/active),
              ficando `NULL` — `<img src={null}>` renderiza quebrado e
              `window.open(null)` não abre nada visível. Corrigido em duas
              frentes: (1) `seed.sql` agora preenche os 3 campos pro
              template Aura Maison (thumbnail de estoque só pra
              demonstração local, `preview_url` apontando pra `/store/
              loja-a`, que já roda esse tema de verdade); (2)
              `Onboarding.tsx` ganhou fallback gracioso pros dois casos —
              sem `thumbnail_url` mostra um placeholder decorativo em vez
              de `<img>` quebrado, sem `preview_url` o botão de preview
              nem aparece (evita abrir uma aba em branco sem explicação) —
              relevante pra quando um lojista real cadastrar um tema sem
              esses campos ainda preenchidos. Validado: `tsc`/`build`
              limpos, lint sem erro novo, e Playwright confirmando a
              imagem carregando de verdade (`naturalWidth > 0`) e o botão
              de preview abrindo `/store/loja-a` de verdade. `supabase db
              reset` rodado pra aplicar o seed corrigido no ambiente local
              que já estava no ar pro usuário testar (dev server não
              precisou reiniciar, só o banco — dados anteriores criados
              pelo usuário nesse ambiente foram perdidos no reset, mesmo
              comportamento already esperado de `db reset`).
              Decisões tomadas: nenhuma nova.
              Pendências deixadas: as mesmas da entrada anterior (Fase 4.1,
              Fase 5). Vale considerar, numa sessão futura que mexer em
              onboarding/templates de novo, se outros campos opcionais de
              `templates` (`marketplace_price`) também merecem fallback
              — não verificado agora por não ter sido reportado.

[2026-09-13] — Implementada a UI de Store Configuration (nome/logo/cores)
              pedida pelo usuário depois de perguntar como editar isso e eu
              apontar que era uma promessa da visão de produto nunca
              formalizada no roadmap. Nova aba "Configurações" no
              Dashboard. Decisão arquitetural registrada: nome/logo vão em
              `stores` (universais, qualquer tema); cores vão em
              `store_theme_configs.config.colors` (Theme Contract), não nas
              colunas legadas `stores.primary_color`/`secondary_color`
              (confirmado sem nenhum consumidor em lugar nenhum do código,
              antes ou depois desta feature — ficam como estão, candidatas
              a limpeza numa migration futura, não tocadas agora). Logo
              reaproveita o bucket `products` já existente (pasta
              `{store_id}/logo/`), sem bucket nem migration novos. Cores
              aplicadas de verdade (não só salvas) em 4 pontos do tema Aura
              Maison: botão "Sacola" do Header, CTA da Hero, pill de
              categoria ativa (cor primária) e contadores de carrinho/
              wishlist (cor de destaque) — documentado explicitamente no
              próprio formulário que isso só vale pro Aura Maison, o
              renderer genérico de 3 layouts não tem esse conceito ainda.
              Logo também exibido no header do renderer genérico (bônus,
              baixo risco). Bug latente encontrado e corrigido no caminho:
              `PublicStore.tsx` nunca gerava signed URL pra
              `store.logo_url` (só fazia isso para `products.image_url`) —
              nunca tinha sido percebido porque não existia UI pra setar um
              logo antes de agora; corrigido só para `logo_url`,
              `banner_url` deixado como está (fora de escopo, sem UI de
              upload de banner pedida). Também atualizado
              `ROADMAP_DE_EXECUCAO.md` com uma seção nova, "Nota de
              processo — checagem Visão vs Roadmap", registrando a lição
              pedida explicitamente pelo usuário: promessas de
              `VISAO_E_MODELO_DE_NEGOCIO.md` sem contrapartida testável no
              roadmap são uma lacuna de processo, não "ainda não
              priorizada" por padrão — sessões futuras que revisarem o
              roadmap ou fecharem uma fase devem varrer a visão de produto
              em busca desse tipo de promessa esquecida.
              Validação: `tsc --noEmit` limpo, `npm run build` OK,
              `npm run lint` sem categoria de erro nova (56 erros, todos
              `no-explicit-any`/pré-existentes, mesmo padrão do resto do
              arquivo). E2E via Playwright: criou loja, ativou Aura Maison,
              preencheu nome/logo/2 cores, salvou, **recarregou a página**
              e confirmou que os valores persistiram de verdade (não só em
              memória), depois confirmou na vitrine pública que o nome
              mudou, o logo apareceu e a cor do botão "Sacola" bate
              exatamente (via `getComputedStyle`, não só inspeção visual)
              com o hex escolhido. Zero erros de console em qualquer
              página tocada. Ambiente do usuário (dev server + Supabase
              local) não precisou reiniciar — sem migration nova, HMR do
              Vite absorveu as mudanças de código sozinho; dados que o
              usuário já tinha criado no ambiente não foram apagados desta
              vez (diferente da correção anterior, que exigiu `db reset`).
              Decisões tomadas: colors em `store_theme_configs`, não em
              `stores.*_color` (ver acima). Nomes dos campos "Cor primária"
              e "Cor de destaque" seguem literalmente os nomes já
              documentados em `THEME_CONTRACT.md` (`colors.primary`,
              `colors.accentPromotion`), não inventados.
              Pendências deixadas: Fase 4.1 (genericização completa) e
              Fase 5 (Checkout/deploy) continuam como próximos itens reais
              do roadmap, não iniciadas. Aplicar cor por loja também no
              renderer genérico de 3 layouts fica como possível follow-up,
              não decidido ainda se vale a pena dado que esse renderer é
              pré-Theme-Contract. Limpeza das colunas legadas
              `stores.primary_color`/`secondary_color` (confirmadas mortas)
              fica para uma migration futura, junto de outras limpezas de
              schema — não urgente, não tocado agora.

[2026-09-13] — Fase 4.1 (genericização completa do Aura Maison) pedida
              explicitamente, com instrução de trabalhar de forma autônoma
              (sem migration nova) mas parar e avisar se descobrisse que
              precisava de campo novo no banco. Aviso dado logo no início:
              o levantamento original desta própria seção já dizia que
              WhatsApp/endereço precisariam de migration — o usuário já
              sabia disso e pediu para eu seguir em frente mesmo assim,
              tratando esses 2 subitens com ausência graciosa (não
              inventando dado), então nenhuma pausa real foi necessária.
              Antes de reescrever qualquer coisa, fiz uma auditoria
              completa do diretório do tema (grep por todos os termos do
              levantamento original + leitura integral dos 11 arquivos) e
              descobri que a genericização já estava, na prática, feita —
              a fatia essencial da Fase 4 escreveu os componentes do zero
              (não copiou+adaptou o zip original por find-replace), então
              o conteúdo fictício de joalheria simplesmente nunca foi
              introduzido no código novo. `CheckoutModal.tsx`/
              `AboutModal.tsx` também nunca foram trazidos pro projeto —
              non-issue confirmado por `ls`. Isso significa que o trabalho
              real desta sessão foi principalmente uma auditoria de
              confirmação com rigor, não uma reescrita — reportado ao
              usuário com total transparência em vez de fingir uma
              reescrita que não foi necessária.
              Validação (checkpoints intermediários, como pedido): `tsc`/
              `lint`/`build` como baseline antes de qualquer coisa (limpo,
              mesma contagem de erros pré-existentes de antes); E2E via
              Playwright criando uma loja de nicho deliberadamente
              diferente ("TechGadgets Brasil", eletrônicos) — escolhida de
              propósito para que qualquer resíduo de "Aura Maison"/joias
              ficasse óbvio por contraste — confirmando zero ocorrência de
              todos os termos proibidos do levantamento (marca, CNPJ fake,
              WhatsApp fixo, códigos de cupom do zip original) em toda a
              vitrine pública renderizada, nome/categoria/produto reais
              corretos, cor primária e logo customizados (da feature de
              Store Configuration da sessão anterior) aplicados de
              verdade, carrinho sem cupom duplicado indo pro `/checkout`
              real, quick view sem CEP/WhatsApp, wishlist funcionando,
              zero erros de console em qualquer página. Ambiente local
              limpo ao final (dev server encerrado, `.env.local` removido,
              `supabase stop`). Nenhuma migration nova foi criada.
              Decisões tomadas: nenhuma nova além da já avisada no início
              (WhatsApp/endereço ficam de fora, ausência graciosa).
              Pendências deixadas: os 2 subitens que dependem de schema
              novo (WhatsApp/endereço/redes sociais reais; rating/reviews/
              variantes de produto) ficam como trabalho futuro explícito,
              sem fase numerada atribuída — só quando o usuário priorizar.
              Fase 5 (Checkout desacoplado de verdade, Pix real, WhatsApp,
              deploy real) é o próximo item real do roadmap principal.
```
